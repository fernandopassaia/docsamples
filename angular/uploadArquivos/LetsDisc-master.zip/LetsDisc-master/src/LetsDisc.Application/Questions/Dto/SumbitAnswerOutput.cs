﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LetsDisc.Questions.Dto
{
    public class SubmitAnswerOutput
    {
        public AnswerDto Answer { get; set; }
    }
}
