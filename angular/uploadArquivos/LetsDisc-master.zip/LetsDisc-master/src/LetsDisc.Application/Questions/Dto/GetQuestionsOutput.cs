﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LetsDisc.Questions.Dto
{
    public class GetQuestionOutput
    {
        public QuestionWithAnswersDto Question { get; set; }
    }
}
