﻿namespace LetsDisc.Posts.Dto
{
    public class AnswerWithQuestion
    {
        public PostDto Question { get; set; }
        public PostDto Answer { get; set; }
    }
}
