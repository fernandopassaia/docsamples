export class Student {
    id: number;
    name: string;
    lastName: string;
    phone: string;
    address: string;
    city: string;
    state: string;
    country: string;
}