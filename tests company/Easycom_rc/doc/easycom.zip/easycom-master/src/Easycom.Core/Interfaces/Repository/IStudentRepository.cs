﻿using Easycom.Core.Entities;

namespace Easycom.Core.Interfaces.Repository
{
    public interface IStudentRepository : IRepository<Student>
    {
    }
}
