﻿namespace Easycom.Core.Base
{
    public class BaseEntity
    {
        public int ID { get; set; }
    }
}
