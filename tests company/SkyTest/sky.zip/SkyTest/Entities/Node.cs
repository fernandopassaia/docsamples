﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SkyTest.Entities
{
    class Node
    {
    }
}
