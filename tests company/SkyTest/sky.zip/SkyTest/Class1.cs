﻿using System;

namespace SkyTest
{
    public class Class1
    {
    }
}
