﻿using SkyTestNode.Entity;

namespace SkyTestNode.Repository
{
    interface INodeRepository
    {
        Node GetNodeRoot();
    }
}
