# AspCoreConsumingWebAPI
ASP.NET Core web application where we will consume web api 
