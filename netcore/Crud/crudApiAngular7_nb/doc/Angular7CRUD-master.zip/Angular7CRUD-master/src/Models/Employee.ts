
export class  Employee{
firstname:string;
lastname:string ;
email:string;
gender:number;
id:string

}