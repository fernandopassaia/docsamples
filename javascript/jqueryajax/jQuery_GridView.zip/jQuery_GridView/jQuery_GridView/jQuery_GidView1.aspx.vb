﻿Public Class jQuery_GidView1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            GridView1.DataSource = GetTabela()
            GridView1.DataBind()
        End If
    End Sub
    Private Function GetTabela() As DataTable
        Dim macTabela As New DataTable()
        macTabela.Columns.Add("Id", GetType(Integer))
        macTabela.Columns.Add("Passatempo", GetType(String))
        macTabela.Columns.Add("Nome", GetType(String))
        macTabela.Columns.Add("Data", GetType(DateTime))

        macTabela.Rows.Add(1, "Ler e estudar", "Macoratti", DateTime.Now)
        macTabela.Rows.Add(2, "Joga video game", "Jefferson", DateTime.Now)
        macTabela.Rows.Add(3, "Ouvir música", "Janice", DateTime.Now)
        macTabela.Rows.Add(4, "Fazer Croche", "Miriam", DateTime.Now)
        macTabela.Rows.Add(5, "Assistir TV", "Bianca", DateTime.Now)
        Return macTabela
    End Function
End Class