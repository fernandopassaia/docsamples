export enum AddressType {
    Billing = 1,
    Shipping = 2
}