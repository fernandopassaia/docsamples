export class UpdateCustomerDto {
    constructor(
        public name: string
    ) {

    }
}
