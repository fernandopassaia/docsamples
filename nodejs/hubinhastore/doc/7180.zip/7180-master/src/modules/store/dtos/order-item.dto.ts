export class OrderItemDto {
    constructor(
        public product: number,
        public quantity: number,
    ) {

    }
}
