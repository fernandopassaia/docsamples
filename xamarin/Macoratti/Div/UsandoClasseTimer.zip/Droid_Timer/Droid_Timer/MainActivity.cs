﻿using Android.App;
using Android.Widget;
using Android.OS;
using System.Timers;
using System;

namespace Droid_Timer
{
    [Activity(Label = "Droid_Timer", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        Timer timer = null;
        TextView txtContador = null;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView (Resource.Layout.Main);

            txtContador = FindViewById<TextView>(Resource.Id.txtvContador);
            var btnIniciar = FindViewById<Button>(Resource.Id.btnInicia);
            var btnCancelar = FindViewById<Button>(Resource.Id.btnCancela);
            var chkInstantaneo = FindViewById<CheckBox>(Resource.Id.chkAtivar);

            btnIniciar.Click += delegate
            {
                 timer = new Timer();
                 if (chkInstantaneo.Checked == true)
                 {
                     timer.Interval = 1000;
                     timer.Elapsed += Timer_Elapsed;
                     timer.Start();
                 }
            };

            btnCancelar.Click += BtnCancelar_Click;
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            Cancelar();
        }

        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            DateTime dt = DateTime.Now;
            string formato = "dd/MM/yyyy HH:mm:ss";
            RunOnUiThread(() => { txtContador.Text = dt.ToString(formato); });
        }

        private void Cancelar()
        {
            timer.Enabled = false;
            timer.Dispose();
        }
    }
}

