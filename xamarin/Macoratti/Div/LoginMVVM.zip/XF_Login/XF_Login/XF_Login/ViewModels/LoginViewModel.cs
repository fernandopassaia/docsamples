﻿using System;
using System.ComponentModel;
using System.Windows.Input;
using Xamarin.Forms;

namespace XF_Login.ViewModels
{
    public class LoginViewModel : INotifyPropertyChanged
    {
        //public Action DisplayInvalidLoginPrompt;
        public Action ExibirAvisoDeLoginInvalido; 

        private string email;
        public string Email
        {
            get { return email; }
            set
            {
                email = value;
                PropertyChanged(this, new PropertyChangedEventArgs("Email"));
            }
        }

        private string senha;

        public event PropertyChangedEventHandler PropertyChanged = delegate { };

        public string Senha
        {
            get { return senha; }
            set
            {
                senha = value;
                PropertyChanged(this, new PropertyChangedEventArgs("Senha"));
            }
        }

        public ICommand SubmitCommand { protected set; get; }

        public LoginViewModel()
        {
            SubmitCommand = new Command(OnSubmit);
        }

        public void OnSubmit()
        {
            if (email != "macoratti@yahoo.com" || senha != "numsey")
            {
                ExibirAvisoDeLoginInvalido();
            }
        }

    }
}
