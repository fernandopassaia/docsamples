﻿using Android.App;
using Android.OS;
using Android.Views;
using Android.Widget;
using System;

namespace App.UsandoListActivity
{
    [Activity(Label = "ListActivity", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : ListActivity
    {
        string[] items;
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView(Resource.Layout.Main);

            items = new string[] { "Visual Basic", "VB .NET", "Visual C#", "Xamarin", "Android", "JavaScript" };
            ListAdapter = new ArrayAdapter<String>(this, Android.Resource.Layout.SimpleListItem1, items);
        }
        protected override void OnListItemClick(ListView l, View v, int position, long id)
        {
            var t = items[position];
            Android.Widget.Toast.MakeText(this, t, Android.Widget.ToastLength.Short).Show();
        }
    }
}

