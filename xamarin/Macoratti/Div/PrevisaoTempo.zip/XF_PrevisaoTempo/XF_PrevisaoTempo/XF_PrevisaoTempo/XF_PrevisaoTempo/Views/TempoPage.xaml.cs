﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using XF_PrevisaoTempo.Service;
using XF_PrevisaoTempo.Model;

namespace XF_PrevisaoTempo.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TempoPage : ContentPage
    {
        public TempoPage()
        {
            InitializeComponent();
            this.Title = "Previsão do Tempo";
            //define o databinding para os objetos padrão iniciais
            this.BindingContext = new Tempo();
        }

        private async void btnPrevisao_Clicked(object sender, EventArgs e)
        {
            try
            {
                if (!String.IsNullOrEmpty(cidadeEntry.Text))
                {
                    Tempo previsaoDoTempo = await DataService.GetPrevisaoDoTempo(cidadeEntry.Text);//Core.GetTempo(cidadeEntry.Text);
                    this.BindingContext = previsaoDoTempo;
                    btnPrevisao.Text = "Nova Previsão";
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Erro ", ex.Message, "OK");
            }
        }
    }
}
