﻿using Android.App;
using Android.OS;
using Android.Widget;
using System.Threading;

namespace AppProgressBar
{
    [Activity(Label = "AppProgressBar", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        Button btnMostraBarra;
        int statusBarra;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);
            btnMostraBarra = FindViewById<Button>(Resource.Id.btnExibirBarra);

            btnMostraBarra.Click += BtnMostraBarra_Click;
        }

        private void BtnMostraBarra_Click(object sender, System.EventArgs e)
        {
            ProgressDialog pbar = new ProgressDialog(this);

            pbar.SetCancelable(true);
            pbar.SetMessage("Carregando módulos do sistema...");
            pbar.SetProgressStyle(ProgressDialogStyle.Horizontal);
            pbar.Progress = 0;
            pbar.Max = 100;
            pbar.Show();

            statusBarra = 0;

            new Thread(new ThreadStart(delegate
            {
                while (statusBarra < 100)
                {
                    statusBarra += 5;
                    pbar.Progress += statusBarra;
                    Thread.Sleep(400);
                }
                RunOnUiThread(() => { pbar.SetMessage("Módulos carregados..."); });
                RunOnUiThread(() => { Toast.MakeText(this, "Módulos carregados com sucesso.", ToastLength.Long).Show(); });
            })).Start();

        }
    }
}

