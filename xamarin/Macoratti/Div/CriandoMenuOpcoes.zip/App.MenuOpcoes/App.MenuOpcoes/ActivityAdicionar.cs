using Android.App;
using Android.OS;

namespace App.MenuOpcoes
{
    [Activity(Label = "ActivityAdicionar")]
    public class ActivityAdicionar : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.Adicionar);
        }
    }
}