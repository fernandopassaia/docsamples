﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;

namespace App.MenuOpcoes
{
    [Activity(Label = "App.MenuOpcoes", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);


            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            //// Get our button from the layout resource,
            //// and attach an event to it
            //Button button = FindViewById<Button>(Resource.Id.MyButton);

            //button.Click += delegate { button.Text = string.Format("{0} clicks!", count++); };
        }

        //public override bool OnPrepareOptionsMenu(IMenu menu)
        //{
        //    MenuInflater.Inflate(Resource.Menu.menu1, menu);
        //    return true;
        //    //return base.OnPrepareOptionsMenu(menu);
        //}


        public override bool OnCreateOptionsMenu(IMenu menu)
        {
            base.OnCreateOptionsMenu(menu);
            MenuInflater inflater = this.MenuInflater;
            inflater.Inflate(Resource.Menu.menu1, menu);

            return true;
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Resource.Id.Adicionar:
                    //Toast.MakeText(this, "Adicionar", ToastLength.Short).Show();
                    var atividadeAdicionar = new Intent(this, typeof(ActivityAdicionar));
                    StartActivity(atividadeAdicionar);
                    break;
                case Resource.Id.Editar:
                    Toast.MakeText(this, "Editar", ToastLength.Short).Show();
                    return true;
                case Resource.Id.Deletar:
                    Toast.MakeText(this, "Deletar", ToastLength.Short).Show();
                    return true;
                case Resource.Id.Cancelar:
                    Toast.MakeText(this, "Cancelar", ToastLength.Short).Show();
                    return true;

            }
            return base.OnOptionsItemSelected(item);
        }
    }
}

