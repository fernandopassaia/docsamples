﻿    using Android.App;
    using Android.OS;
    using Android.Widget;

    namespace App.ExibirVideo
    {
        [Activity(Label = "App.ExibirVideo", MainLauncher = true, Icon = "@drawable/icon")]
        public class MainActivity : Activity
        {
            VideoView video;
            string videoPath;

            protected override void OnCreate(Bundle bundle)
            {
                base.OnCreate(bundle);

                // Set our view from the "main" layout resource
                SetContentView(Resource.Layout.Main);

                // Get our button from the layout resource,
                // and attach an event to it
                Button button = FindViewById<Button>(Resource.Id.btnExibir);
                video = FindViewById<VideoView>(Resource.Id.videoView);
                EditText txtVideo = FindViewById<EditText>(Resource.Id.txtVideo);


                //videoPath = string.Format("android.resource://{0}/{1}", "app.ExibirVideo", Resource.Raw.Leaning);
                //video.SetVideoPath(videoPath);

                var uri = Android.Net.Uri.Parse(txtVideo.Text);
                //var uri = Android.Net.Uri.Parse(videoPath);


                button.Click += delegate
                {
                    if (uri != null)
                    {
                        video.SetVideoURI(uri);
                        //video.SetVideoPath(videoPath);
                        video.Start();
                    }
                    else
                    {
                        Toast.MakeText(this, "Informe a URI do vídeo", ToastLength.Short).Show();
                    }
                };
            }
        }
    }

