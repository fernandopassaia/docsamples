﻿using Android.App;
using Android.Widget;
using Android.OS;
using Android;
using System.IO;
using System;
using System.Collections.Generic;
using System.Linq;

[assembly: UsesPermission(Manifest.Permission.WriteExternalStorage)]
[assembly: UsesPermission(Manifest.Permission.ReadExternalStorage)]

namespace Droid_FileSystem
{
    [Activity(Label = "FileSystem", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        private const string MeuArquivo = "Mac.txt";
        private const string ValorTexto = "Macoratti .net - Android";

        private string caminhoBase = "";
        private string nomeArquivoBase = "";

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView (Resource.Layout.Main);

            // Permite selecionar o local
            var spinner = FindViewById<Spinner>(Resource.Id.spinner);
            var labelCaminhoBase = FindViewById<TextView>(Resource.Id.labelCaminhoBase);
            var dic = new Dictionary<string, string> {
                { "Arquivos Internos", FilesDir.AbsolutePath },
                { "Arquivos Externos", GetExternalFilesDir (null).AbsolutePath },
                { "Cache Interno", CacheDir.AbsolutePath },
                { "Cache Externo", ExternalCacheDir.AbsolutePath },
                { "Downloads Publicos", Android.OS.Environment.GetExternalStoragePublicDirectory (Android.OS.Environment.DirectoryDownloads).AbsolutePath },
            };

            string[] chaves = dic.Keys.ToArray();

            var adapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleSpinnerItem, chaves);

            adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);

            spinner.Adapter = adapter;

            spinner.ItemSelected += (sender, e) => {
                string chave = chaves[e.Position];
                caminhoBase = dic[chave];
                nomeArquivoBase = Path.Combine(caminhoBase, MeuArquivo);
                // atualiza aUI
                labelCaminhoBase.Text = string.Format("Base: {0}\n\nCaminho Arquivo: {1}", caminhoBase, nomeArquivoBase);
            };

            //obtém a referencia aos controles
            var verificaArquivo = FindViewById<Button>(Resource.Id.verificaArquivo);
            var LeArquivo = FindViewById<Button>(Resource.Id.leArquivo);
            var EscreveArquivo = FindViewById<Button>(Resource.Id.escreveArquivo);
            var ListaArquivos = FindViewById<Button>(Resource.Id.listaArquivos);
            var EstadoArmazenagem = FindViewById<Button>(Resource.Id.EstadoArmazenagem);
            var labelMensagem = FindViewById<TextView>(Resource.Id.lblMensagem);

            // define as operações
            verificaArquivo.Click += delegate {
                try
                {
                    // verifica se o arquivo existe
                    var exists = File.Exists(nomeArquivoBase);
                    // atualiza a UI
                    labelMensagem.Text = "O Arquivo Existe: " + exists;
                }
                catch (Exception ex)
                {
                    // exibe mensagens de erros na  UI
                    labelMensagem.Text = ex.Message;
                }
            };

            LeArquivo.Click += delegate {
                try
                {
                    // le o valor do arquivo
                    string valor = File.ReadAllText(nomeArquivoBase);
                    // atualiza a UI
                    labelMensagem.Text = "O valor é : " + valor;
                }
                catch (Exception ex)
                {
                    // exibe mensagens de erros na  UI
                    // uma exceção ocorre se o arquivo não existe
                    labelMensagem.Text = ex.Message;
                }
            };

            EscreveArquivo.Click += delegate {
                // verifica os erros
                try
                {
                    // escreve o valor no arquivo
                    File.WriteAllText(nomeArquivoBase, ValorTexto);
                    //atualiza a UI
                    labelMensagem.Text = "O texto foi escrito no arquivo.";
                }
                catch (Exception ex)
                {
                    // exibe mensagens de erros na  UI
                    labelMensagem.Text = ex.Message;
                }
            };

            ListaArquivos.Click += delegate {
                try
                {
                    // lista os arquivos
                    var arquivos = Directory.GetFiles(caminhoBase);
                    var valor = string.Join(System.Environment.NewLine, arquivos);
                    labelMensagem.Text = "Os arquivos são: \n" + valor;
                }
                catch (Exception ex)
                {
                    labelMensagem.Text = ex.Message;
                }
            };

            EstadoArmazenagem.Click += delegate {
                var gravavel = Android.OS.Environment.ExternalStorageState == Android.OS.Environment.MediaMounted;
                var legivel = gravavel || Android.OS.Environment.ExternalStorageState == Android.OS.Environment.MediaMountedReadOnly;

                var arquivo = new Java.IO.File(caminhoBase);

                const int bytesInMB = 1000 * 1000;

                labelMensagem.Text = string.Format(
                    "Legível: {0}\nGravável: {1}\nEspaço Livre: {2} MB\nEspaço Total: {3} MB\n",
                    legivel, gravavel, arquivo.FreeSpace / bytesInMB, arquivo.TotalSpace / bytesInMB);
            };
        }
    }
}

