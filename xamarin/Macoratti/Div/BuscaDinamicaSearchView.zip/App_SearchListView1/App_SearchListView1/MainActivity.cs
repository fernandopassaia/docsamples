﻿using Android.App;
using Android.OS;
using Android.Widget;
using System.Collections;

namespace App_SearchListView1
{
    [Activity(Label = "App_SearchListView1", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        private SearchView sv1;
        private ListView lv1;
        private ArrayAdapter adp1;
        private ArrayList lista;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            sv1 = FindViewById<SearchView>(Resource.Id.svw1);
            lv1 = FindViewById<ListView>(Resource.Id.lvw1);

            AdicionarDados();

            adp1 = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1, lista);
            lv1.Adapter = adp1;

            sv1.QueryTextChange += Sv1_QueryTextChange;

            lv1.ItemClick += Lv1_ItemClick;

        }

        private void Lv1_ItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            Toast.MakeText(this, adp1.GetItem(e.Position).ToString(), ToastLength.Short).Show();
        }

        private void Sv1_QueryTextChange(object sender, SearchView.QueryTextChangeEventArgs e)
        {
            adp1.Filter.InvokeFilter(e.NewText);
        }

        private void AdicionarDados()
        {
            lista = new ArrayList();
            lista.Add("Macoratti");
            lista.Add("Mario");
            lista.Add("Jefferson");
            lista.Add("Janice");
            lista.Add("Jessica");
            lista.Add("Maria");
            lista.Add("Bianca");
            lista.Add("Bruna");
        }
    }
}

