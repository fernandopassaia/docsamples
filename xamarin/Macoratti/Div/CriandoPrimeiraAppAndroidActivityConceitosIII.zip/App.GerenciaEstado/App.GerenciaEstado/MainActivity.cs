﻿using Android.App;
using Android.OS;
using Android.Widget;

namespace App.GerenciaEstado
{
    [Activity(Label = "App.GerenciaEstado", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        int contador = 1;
        EditText edtxtNome;
        Button btnNome;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView(Resource.Layout.Main);


            edtxtNome = FindViewById<EditText>(Resource.Id.edtNome);
            btnNome = FindViewById<Button>(Resource.Id.button1);

            Button button = FindViewById<Button>(Resource.Id.MyButton);
            button.Click += delegate { button.Text = string.Format("{0} clique(s) !", contador++); };
        }

        protected override void OnSaveInstanceState(Bundle outState)
        {
            base.OnSaveInstanceState(outState);

            outState.PutString("NOME_USUARIO", edtxtNome.Text.ToString());
            outState.PutInt("CONTADOR", contador);
        }

        protected override void OnRestoreInstanceState(Bundle savedInstanceState)
        {
            base.OnRestoreInstanceState(savedInstanceState);

            savedInstanceState.GetString("NOME_USUARIO");
            btnNome.Text = savedInstanceState.GetString("NOME_USUARIO");
            contador = savedInstanceState.GetInt("CONTADOR");
        }

    }
}

