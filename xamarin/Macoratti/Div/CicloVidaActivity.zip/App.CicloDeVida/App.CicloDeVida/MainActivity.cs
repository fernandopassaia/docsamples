﻿using Android.App;
using Android.OS;
using Android.Util;
using Android.Widget;

namespace App.CicloDeVida
{
    [Activity(Label = "App.CicloDeVida", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        int count = 1;

        protected override void OnCreate(Bundle bundle)
        {
            Log.Debug(GetType().FullName, "<< OnCreate >>");
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.Main);

            if (bundle != null)
            {
                Log.Debug(GetType().FullName, "<< OnCreate >> - bundle diferente de null");

            }

            Button button = FindViewById<Button>(Resource.Id.MyButton);
            button.Click += delegate { button.Text = string.Format("{0} clicks!", count++); };
        }

        protected override void OnSaveInstanceState(Bundle outState)
        {
            Log.Debug(GetType().FullName, "<< OnSaveInstanceState() >>");
            base.OnSaveInstanceState(outState);
        }

        protected override void OnRestoreInstanceState(Bundle savedInstanceState)
        {
            Log.Debug(GetType().FullName, "<< OnRestoreInstanceState() >>");
            base.OnRestoreInstanceState(savedInstanceState);
        }

        protected override void OnDestroy()
        {
            Log.Debug(GetType().FullName, "<< On Destroy >>");
            base.OnDestroy();
        }

        protected override void OnPause()
        {
            Log.Debug(GetType().FullName, "<< On Pause >>");
            base.OnPause();
        }

        protected override void OnRestart()
        {
            Log.Debug(GetType().FullName, "<< On Restart >>");
            base.OnRestart();
        }

        protected override void OnResume()
        {
            Log.Debug(GetType().FullName, "<< On Resume >>");
            base.OnResume();
        }

        protected override void OnStart()
        {
            Log.Debug(GetType().FullName, "<< On Start >>");
            base.OnStart();
        }

        protected override void OnStop()
        {
            Log.Debug(GetType().FullName, "<< On Stop >>");
            base.OnStop();
        }
    }
}

