﻿using Android.App;
using Android.OS;
using Android.Widget;

namespace App.Login
{
    [Activity(Label = "App.Login", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView(Resource.Layout.Login);

            EditText usuario = FindViewById<EditText>(Resource.Id.nomeUsuario);
            usuario.SetTextColor(Android.Graphics.Color.Yellow);

            EditText senha = FindViewById<EditText>(Resource.Id.senha);
            senha.SetTextColor(Android.Graphics.Color.Yellow);


            Button login = FindViewById<Button>(Resource.Id.login);

            login.Click += delegate
            {

                Toast.MakeText(this, "Botão de Login foi clicado!", ToastLength.Short).Show();

            };
        }
    }
}

