﻿using Android.App;
using Android.Widget;
using Android.OS;
using System;

namespace Droid_ListViewCrud_Array
{
    [Activity(Label = "Droid_ListView_Ordenacao", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        //Views
        private ListView lv;
        private Button btnOrdenar;

        //dados
        private readonly string[] planetas = { "Júpiter", "Netuno", "Urano", "Saturno", "Marte", "Terra", "Mércurio", "Vênus" };
        private bool ascendente = true;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView (Resource.Layout.Main);

            this.InicializarViews();
            this.OrdenaDados(ascendente);
            this.ascendente = !ascendente;
            btnOrdenar.Click += BtnOrdenar_Click;
            lv.ItemClick += Lv_ItemClick;
        }

        //exibe o nome o planeta selecionado ao clicar em um item no ListView
        private void Lv_ItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            using (var dialog = new AlertDialog.Builder(this))
            {
                int posicao = e.Position;
                string valor = planetas[posicao];
                dialog.SetTitle("Planeta Selecionado");
                dialog.SetMessage(valor);
                dialog.Show();
            }
        }

        private void BtnOrdenar_Click(object sender, EventArgs e)
        {
            OrdenaDados(ascendente);
            this.ascendente = !ascendente;
        }

        //Inicializar Views
        private void InicializarViews()
        {
            lv = FindViewById<ListView>(Resource.Id.lv);
            btnOrdenar = FindViewById<Button>(Resource.Id.btnOrdenar);
        }
        //Preencher Listview
        private void PopularListView()
        {
            lv.Adapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1, planetas);
        }

       
        /*
         * Ordenar
         */
        private void OrdenaDados(bool asc)
        {
            //Ordena o array :  ascendente e descendente
            if (asc)
            {
                Array.Sort(planetas);
            }
            else
            {
                Array.Reverse(planetas);
            }
            //Limpa e preenche o Listview (sem MVVM)
            PopularListView();
        }
    }
}

