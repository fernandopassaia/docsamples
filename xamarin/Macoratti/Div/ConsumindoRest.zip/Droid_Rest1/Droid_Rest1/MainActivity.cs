﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Xml.Serialization;
using Android.App;
using Android.Widget;
using Android.OS;
using Newtonsoft.Json;

namespace Droid_Rest1
{
    [Activity(Label = "Consumindo Serviços REST", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView (Resource.Layout.Main);
            Button lerJson = FindViewById<Button>(Resource.Id.lerJson);
            Button lerXml = FindViewById<Button>(Resource.Id.lerXml);
            Button enviarDados = FindViewById<Button>(Resource.Id.enviarDados);
            TextView textView = FindViewById<TextView>(Resource.Id.textView);

            lerJson.Click += async delegate
            {
                using (var client = new HttpClient())
                {
                    // envia a requisição GET
                    var uri = "http://jsonplaceholder.typicode.com/posts";
                    var result = await client.GetStringAsync(uri);

                    // processa a resposta
                    var posts = JsonConvert.DeserializeObject<List<Post>>(result);

                    // gera a saida
                    var post = posts.First();
                    textView.Text = "Primeiro post:\n\n" + post;
                }
            };

            lerXml.Click += async delegate
            {
                using (var client = new HttpClient())
                {
                    // envia uma requição GET
                    var uri = "http://blog.xamarin.com/feed";
                    var result = await client.GetStreamAsync(uri);

                    // processa a resposta
                    var serializer = new XmlSerializer(typeof(Rss));
                    var feed = (Rss)serializer.Deserialize(result);

                    // gera a saida
                    var item = feed.Channel.Items.First();
                    textView.Text = "Primeiro Item:\n\n" + item;
                }
            };

            enviarDados.Click += async delegate
            {
                using (var client = new HttpClient())
                {
                    // cria um novo post
                    var novoPost = new Post
                    {
                        UserId = 12,
                        Title = "Meu primeiro Post",
                        Content = "Macoratti .net - Quase tudo para .NET!"
                    };

                    // cria o conteudo da requisição e define o tipo Json
                    var json = JsonConvert.SerializeObject(novoPost);
                    var content = new StringContent(json, Encoding.UTF8, "application/json");

                    // envia a requisição POST
                    var uri = "http://jsonplaceholder.typicode.com/posts";
                    var result = await client.PostAsync(uri, content);

                    // Se ocorrer um erro lança uma exceção
                    result.EnsureSuccessStatusCode();

                    // processa a resposta
                    var resultString = await result.Content.ReadAsStringAsync();
                    var post = JsonConvert.DeserializeObject<Post>(resultString);

                    // exibe a saida no TextView
                    textView.Text = post.ToString();
                }
            };

        }
    }
}

