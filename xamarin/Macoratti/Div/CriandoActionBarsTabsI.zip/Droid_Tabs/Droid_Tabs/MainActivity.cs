﻿using Android.App;
using Android.Widget;
using Android.OS;
using System;

namespace Droid_Tabs
{
    [Activity(Label = "Droid_Tabs", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        TextView textView;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView (Resource.Layout.Main);

            textView = FindViewById<TextView>(Resource.Id.textView1);

            ActionBar.NavigationMode = ActionBarNavigationMode.Tabs;

            // Add the tabs to Action Bar  
            AddTab("Tab Um");
            AddTab("Tab Dois");
        }

        private void AddTab(string tabTexto)
        {
            ActionBar.Tab tab = ActionBar.NewTab();
            tab.SetText(tabTexto);
            tab.TabSelected += OnTabSelected;
            ActionBar.AddTab(tab);
        }

        private void OnTabSelected(object sender, ActionBar.TabEventArgs e)
        {
            var TabAtual = (ActionBar.Tab)sender;

            if (TabAtual.Position == 0)
            {
                textView.Text = "Esta é a TAB Um que foi selecionada";
            }

            else
            {
                textView.Text = "Esta é TAB DOIS que foi Selecionada";
            }
        }
    }
}

