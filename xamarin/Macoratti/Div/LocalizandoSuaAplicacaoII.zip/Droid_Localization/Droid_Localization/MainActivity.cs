﻿using Android.App;
using Android.Widget;
using Android.OS;
using System.Threading;
using System.Globalization;
using System.Resources;
using System.Reflection;

namespace Droid_Localization
{
    [Activity(Label = "@string/app", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        // carrega o arquivo de Recurso contento a informação da cultura especificada
        string codigoCultura = "es-ES";
        ResourceManager resxManager = new ResourceManager("Droid_Localization.AppResources.Lang", Assembly.GetExecutingAssembly());

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView (Resource.Layout.Main);

            // define o idioma e a cultura 
            Thread.CurrentThread.CurrentUICulture = new CultureInfo(codigoCultura);
            Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(codigoCultura);

            //obtem o locale atual
            //var lang = Resources.Configuration.Locale;

            var btnCancel = FindViewById<Button>(Resource.Id.btnCancel);
            var btnAdd = FindViewById<Button>(Resource.Id.btnAdd);
            var btnNotes = FindViewById<Button>(Resource.Id.btnNotes);
            var btnDone = FindViewById<Button>(Resource.Id.btnDone);

            if (btnCancel != null)
            {
                btnCancel.Text = Resources.GetText(Resource.String.cancel); 
            }
            if (btnAdd != null)
            {
                btnAdd.Text = resxManager.GetString("add");
            }
            if (btnNotes != null)
            {
                btnNotes.Text = resxManager.GetString("notes");
            }
            if (btnDone != null)
            {
                btnDone.Text = resxManager.GetString("done");
            }
        }
    }
}

