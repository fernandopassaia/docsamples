﻿using System;
using Xamarin.Forms;

namespace XF_PclStorage
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        string[] valor;
        string nome;
        string usuario;
        string senha;

        private async void btnLogin_Click(object sender, EventArgs e)
        {
            bool existe = await PCLHelper.ArquivoExisteAsync(txtUsuario.Text);

            if (existe != true)
            {
                await DisplayAlert("Login", "Login falhou... Tente Novamente...", "OK");
            }
            else
            {
                LeInfoUsuario(txtUsuario.Text);
                if (usuario == txtUsuario.Text && senha == txtSenha.Text)
                {
                    await DisplayAlert("Login", "Login feito com sucesso ... \nAgora Edite o seu perfil", "OK");
                    await Navigation.PushModalAsync(new PerfilPage(txtUsuario.Text));
                }
                else
                {
                    await DisplayAlert("Login", "Login falhou... Tente Novamente...", "OK");
                    txtUsuario.Text = "";
                    txtSenha.Text = "";
                    txtUsuario.Focus();
                }
            }
        }

        public async void LeInfoUsuario(string arquivo)
        {
            string conteudo = await PCLHelper.ReadAllTextAsync(arquivo);
            valor  = conteudo.Split('\n');
            nome = valor[0].ToString();
            usuario = valor[1].ToString();
            senha = valor[2].ToString();
        }

        private async void btnRegistro_Click(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new RegistroPage());
        }
    }
}
