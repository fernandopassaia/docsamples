﻿using System;
using System.Text;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace XF_PclStorage
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PerfilPage : ContentPage
    {
        public PerfilPage(string usuario)
        {
            InitializeComponent();
            LeInfoUsuario(usuario);
        }

        public async void LeInfoUsuario(string usuario)
        {
            string conteudo = await PCLHelper.ReadAllTextAsync(usuario);
            string[] valor = conteudo.Split('\n');
            txtNome.Text = valor[0].ToString();
            txtUsuario.Text = valor[1].ToString();
            txtSenha.Text = valor[2].ToString();
        }

        private async void btnLogin_Click(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new MainPage());
        }

        public string ContentBuilder(params string[] content)
        {
            StringBuilder contentbuilder = new StringBuilder();
            foreach (var item in content)
            {
                contentbuilder.AppendLine(item.ToString());
            }
            return contentbuilder.ToString();
        }

        private async void btnAtualizaPerfil_Click(object sender, EventArgs e)
        {
            bool resultado = false;

            bool arquivoExiste = await txtUsuario.Text.ArquivoExisteAsync();
            if (arquivoExiste == true)
            {
                if (!string.IsNullOrEmpty(txtNome.Text) && !string.IsNullOrEmpty(txtSenha.Text) && !string.IsNullOrEmpty(txtUsuario.Text))
                    resultado = await txtUsuario.Text.WriteTextAllAsync(ContentBuilder(txtNome.Text, txtUsuario.Text, txtSenha.Text));

                if (resultado != true)
                {
                    await DisplayAlert("Atualiza Perfil", "Atualização falhou...\nTente novamente", "OK");
                }
                else
                {
                    await DisplayAlert("Atualiza Perfil", "Perfil atualizado com sucesso.", "OK");

                }
            }
            else
            {
                await DisplayAlert("Atualiza Perfil", "Tente novamente.", "OK");
            }
        }
    }
}