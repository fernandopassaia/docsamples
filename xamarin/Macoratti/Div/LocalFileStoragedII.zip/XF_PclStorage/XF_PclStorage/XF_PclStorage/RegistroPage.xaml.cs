﻿using System;
using System.Text;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace XF_PclStorage
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class RegistroPage : ContentPage
    {
        public RegistroPage()
        {
            InitializeComponent();
        }

        private async void btnRegistro_Click(object sender, EventArgs e)
        {
            bool resultado = false;
            bool arquivoExiste = await txtUsuario.Text.ArquivoExisteAsync();

            if (arquivoExiste != true)
            {
                if (!string.IsNullOrEmpty(txtNome.Text)  && !string.IsNullOrEmpty(txtSenha.Text) && !string.IsNullOrEmpty(txtUsuario.Text))
                    resultado = await txtUsuario.Text.WriteTextAllAsync(ContentBuilder(txtNome.Text, txtUsuario.Text, txtSenha.Text));

                if (resultado != true)
                {
                    await DisplayAlert("Registro", "Registro Falhou .. \nTente novamente", "OK");
                }
                else
                {
                    await DisplayAlert("Registro", "Registro feito com Sucesso... \nFaça o Login e Edite o Perfil", "OK");
                    await Navigation.PushModalAsync(new MainPage());
                }
            }
            else
            {
                await DisplayAlert("Registro Falhou", "Nome do usuário já existe... \nTente um nome diferente", "OK");
                txtUsuario.Text = "";
                txtUsuario.Focus();
            }
        }

        public string ContentBuilder(params string[] content)
        {
            StringBuilder contentbuilder = new StringBuilder();
            foreach (var item in content)
            {
                contentbuilder.AppendLine(item.ToString());
            }
            return contentbuilder.ToString();
        }

        private async void btnLogin_Click(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new MainPage());
        }
    }
}