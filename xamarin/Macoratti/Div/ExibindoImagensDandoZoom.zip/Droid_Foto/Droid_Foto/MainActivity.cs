﻿using Android.App;
using Android.Widget;
using Android.OS;
using UK.CO.Senab.Photoview;
using Android.Graphics.Drawables;

namespace Droid_Foto
{
    [Activity(Label = "Droid_Foto", MainLauncher = true, Icon = "@drawable/icon", Theme ="@style/Theme.AppCompat.Light.NoActionBar")]
    public class MainActivity : Activity
    {
        ImageView imageView;
        PhotoViewAttacher photoViewAttacher;
        Button btnMudarImagem;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);
            imageView = FindViewById<ImageView>(Resource.Id.imageView);
            btnMudarImagem = FindViewById<Button>(Resource.Id.btnMudarImagem);

            Drawable bitmap = Resources.GetDrawable(Resource.Drawable.potw1706a);
            imageView.SetImageDrawable(bitmap);
            photoViewAttacher = new PhotoViewAttacher(imageView);

            btnMudarImagem.Click += BtnMudarImagem_Click;
        }

        private void BtnMudarImagem_Click(object sender, System.EventArgs e)
        {
            var imageView = FindViewById<ImageView>(Resource.Id.imageView);

            Drawable bitmap = Resources.GetDrawable(Resource.Drawable.hubble_friday_05132016);
            imageView.SetImageDrawable(bitmap);
            photoViewAttacher = new PhotoViewAttacher(imageView);
        }
    };
}
    


