﻿using System;
using Xamarin.Forms;
using XF_PaginaPesquisa.Views;

namespace XF_PaginaPesquisa
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private async void OnTapCategorias(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new CategoriasPage(CategoriaNome, CategoriaId));
        }
    }
}
