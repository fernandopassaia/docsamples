﻿using System.Collections.ObjectModel;
using XF_PaginaPesquisa.Model;

namespace XF_PaginaPesquisa.Service
{
    public class CategoriaService
    {
        private ObservableCollection<Categoria> categorias = new ObservableCollection<Categoria>();
        public CategoriaService()
        { }

        public ObservableCollection<Categoria> GetCategorias()
        {
            categorias.Add(new Categoria() { CategoriaId = 1, Nome = "Equipamentos" });
            categorias.Add(new Categoria() { CategoriaId = 2, Nome = "Acessórios" });
            categorias.Add(new Categoria() { CategoriaId = 3, Nome = "Notebooks" });
            categorias.Add(new Categoria() { CategoriaId = 4, Nome = "Impressoras" });
            categorias.Add(new Categoria() { CategoriaId = 5, Nome = "SmartPhones" });
            categorias.Add(new Categoria() { CategoriaId = 6, Nome = "Tablets" });
            categorias.Add(new Categoria() { CategoriaId = 7, Nome = "Toners" });
            categorias.Add(new Categoria() { CategoriaId = 8, Nome = "TVs" });

            return categorias;
        }

        public void Add(Categoria categoria)
        {
            categorias.Add(categoria);
        }
    }
}
