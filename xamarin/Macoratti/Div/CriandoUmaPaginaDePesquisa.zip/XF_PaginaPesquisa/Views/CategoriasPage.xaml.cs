﻿using System.Collections.Generic;
using System.Linq;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using XF_PaginaPesquisa.Model;
using XF_PaginaPesquisa.Service;

namespace XF_PaginaPesquisa.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CategoriasPage : ContentPage
    {
        private Label nome;
        private Label valor;
        private IEnumerable<Categoria> itens;
        CategoriaService categ = new CategoriaService();

        public CategoriasPage(Label nome, Label valor)
        {
            InitializeComponent();
            itens = categ.GetCategorias();
            this.valor = valor;
            this.nome = nome;
        }

        private void OnTextChanged(object sender, TextChangedEventArgs e)
        {
            lvwCategorias.BeginRefresh();
            if (string.IsNullOrWhiteSpace(e.NewTextValue))
                {
                     lvwCategorias.ItemsSource = itens;
                }
            else
                {
                    lvwCategorias.ItemsSource = itens.Where(i => i.Nome.Contains(e.NewTextValue));
            }
            lvwCategorias.EndRefresh();
        }

        private async void lvwCategorias_OnItemTapped(object sender, ItemTappedEventArgs e)
        {
            var item = (sender as ListView).SelectedItem as Categoria;
            this.valor.Text = item.CategoriaId.ToString();
            this.nome.Text = item.Nome;
            await Navigation.PopAsync();

        }
    }
}
