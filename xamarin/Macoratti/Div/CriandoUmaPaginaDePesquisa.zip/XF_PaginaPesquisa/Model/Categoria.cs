﻿namespace XF_PaginaPesquisa.Model
{
    public class Categoria
    {
        public long? CategoriaId { get; set; }
        public string Nome { get; set; }
    }
}
