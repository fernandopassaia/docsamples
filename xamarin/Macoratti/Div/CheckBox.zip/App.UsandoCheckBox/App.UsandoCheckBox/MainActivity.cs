﻿using Android.App;
using Android.OS;
using Android.Views;
using Android.Widget;
using Java.Interop;

namespace App.UsandoCheckBox
{
    [Activity(Label = "App.UsandoCheckBox", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        //declara as views
        CheckBox chkb1, chkb2, chkb3, chkb4, chkb5;
        TextView txtv2;
        EditText edtxt1;

        //define o tratamento do evento Click
        [Export("chkb_OnClick")]
        public void chkb_OnClick(View v)
        {
            //verifica o componente clicado
            switch (v.Id)
            {
                case Resource.Id.checkBox1:
                    Toast.MakeText(this, "Cliquei no checkbox1", ToastLength.Short).Show();
                    break;
                case Resource.Id.checkBox2:
                    Toast.MakeText(this, "Cliquei no checkbox2", ToastLength.Short).Show();
                    break;
                case Resource.Id.checkBox3:
                    Toast.MakeText(this, "Cliquei no checkbox3", ToastLength.Short).Show();
                    break;
                case Resource.Id.checkBox4:
                    Toast.MakeText(this, "Cliquei no checkbox4", ToastLength.Short).Show();
                    break;
            }
        }

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            chkb1 = FindViewById<CheckBox>(Resource.Id.checkBox1);
            chkb2 = FindViewById<CheckBox>(Resource.Id.checkBox2);
            chkb3 = FindViewById<CheckBox>(Resource.Id.checkBox3);
            chkb4 = FindViewById<CheckBox>(Resource.Id.checkBox4);
            chkb5 = FindViewById<CheckBox>(Resource.Id.checkBox5);
            //textview
            txtv2 = FindViewById<TextView>(Resource.Id.textView2);
            txtv2.Visibility = ViewStates.Invisible;
            //edittext
            edtxt1 = FindViewById<EditText>(Resource.Id.edittext);
            edtxt1.Visibility = ViewStates.Invisible;

            //evento do checkbox
            chkb5.CheckedChange += Chkb5_CheckedChange;

        }

        //tratamento do evento CheckedChange
        private void Chkb5_CheckedChange(object sender, CompoundButton.CheckedChangeEventArgs e)
        {
            CheckBox checkbox = (CheckBox)sender;

            //oculta/exibe o textView e o EditText
            if (checkbox.Checked)
            {
                txtv2.Visibility = ViewStates.Visible;
                edtxt1.Visibility = ViewStates.Visible;
            }
            else
            {
                txtv2.Visibility = ViewStates.Invisible;
                edtxt1.Visibility = ViewStates.Invisible;
            }
        }
    }
}

