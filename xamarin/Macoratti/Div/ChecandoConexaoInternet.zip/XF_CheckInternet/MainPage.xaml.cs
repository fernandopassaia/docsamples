﻿using System.Linq;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace XF_CheckInternet
{
    public partial class MainPage : ContentPage
	{
		public MainPage()
		{
			InitializeComponent();

            var internet = Connectivity.NetworkAccess;
            var perfis = Connectivity.Profiles;

            //verifica o acesso à internet
            if (internet == NetworkAccess.Internet)
            {
                lblNetworkStatus.Text = "A internet esta Disponível";
            }
            else
            {
                lblNetworkStatus.Text = "A internet esta Indisponível";
            }

            //verifica o perfil de conectividade
            if (perfis.Contains(ConnectionProfile.WiFi))
            {
                lblNetworkPerfil.Text = perfis.FirstOrDefault().ToString();
            }
            else
            {
                lblNetworkPerfil.Text = perfis.FirstOrDefault().ToString();
            }
        }
	}
}
