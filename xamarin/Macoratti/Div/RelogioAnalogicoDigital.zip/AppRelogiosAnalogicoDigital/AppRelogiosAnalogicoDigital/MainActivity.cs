﻿using Android.App;
using Android.OS;
using Android.Widget;

namespace AppRelogiosAnalogicoDigital
{
    [Activity(Label = "AppRelogiosAnalogicoDigital", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            var relogioAnalogico = FindViewById<AnalogClock>(Resource.Id.analogClock1);
            relogioAnalogico.Visibility = Android.Views.ViewStates.Invisible;
            var btnAnalogico = FindViewById<Button>(Resource.Id.btnExibir);

            btnAnalogico.Click += (sender, e) =>
            {
                btnAnalogico.Text = "Relógio Analógico";
                relogioAnalogico.Visibility = Android.Views.ViewStates.Visible;
            };

            var relogioDigital = FindViewById<DigitalClock>(Resource.Id.digitalClock1);
            var btnDigital = FindViewById<Button>(Resource.Id.btnDigital);
            relogioDigital.Visibility = Android.Views.ViewStates.Invisible;

            btnDigital.Click += (sender, e) =>
            {
                btnAnalogico.Text = "Relógio Digital";
                //relogioDigital.SetCursorVisible(true);
                relogioDigital.Visibility = Android.Views.ViewStates.Visible;
            };
        }
    }
}

