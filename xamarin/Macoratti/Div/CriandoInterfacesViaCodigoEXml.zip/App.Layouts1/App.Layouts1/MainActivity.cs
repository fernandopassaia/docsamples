﻿using Android.App;
using Android.OS;
using Android.Widget;

namespace App.Layouts1
{
    [Activity(Label = "App.Layouts1", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            ////cria uma instância do Layout LinearLayout
            //LinearLayout layout = new LinearLayout(this);
            //layout.SetBackgroundColor(Android.Graphics.Color.Gray);
            ////define a orientação do leiaute
            //layout.Orientation = Orientation.Vertical;
            ////define um TextView
            //TextView lblNome = new TextView(this);
            //lblNome.Text = "Informe o nome";
            ////define um EditText
            //EditText txtNome = new EditText(this);
            ////define um button
            //Button button = new Button(this);
            ////atribui um texto ao button
            //button.Text = "Macoratti .net!";
            //button.SetBackgroundColor(Android.Graphics.Color.Red);
            ////inclui o button no leiaute
            //layout.AddView(lblNome, ViewGroup.LayoutParams.MatchParent, ViewGroup.LayoutParams.WrapContent);
            //layout.AddView(txtNome, ViewGroup.LayoutParams.MatchParent, ViewGroup.LayoutParams.WrapContent);
            //layout.AddView(button, ViewGroup.LayoutParams.MatchParent, ViewGroup.LayoutParams.WrapContent);
            ////define o layout como a view principal
            //SetContentView(layout);

            // Set our view from the "main" layout resource
            int contador = 1;
            SetContentView(Resource.Layout.Main);
            // Get our button from the layout resource,
            // and attach an event to it
            Button button = FindViewById<Button>(Resource.Id.button1);
            button.Click += delegate
            {
                button.Text = string.Format("{0} cliques !", contador++);
            };
        }
    }
}

