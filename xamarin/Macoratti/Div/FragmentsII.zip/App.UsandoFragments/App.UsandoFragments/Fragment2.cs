using Android.App;
using Android.OS;
using Android.Views;

namespace App.UsandoFragments
{
    public class Fragment2 : Fragment
    {
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View view = inflater.Inflate(Resource.Layout.Fragment2, container, false);
            return view;
        }

    }
}