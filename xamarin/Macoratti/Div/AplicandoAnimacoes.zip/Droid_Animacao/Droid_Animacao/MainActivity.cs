﻿using Android.App;
using Android.Widget;
using Android.OS;
using Android.Animation;

namespace Droid_Animacao
{
    [Activity(Label = "Droid_Animacao", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        ImageView imgView;
        Button btnAnimacao;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.Main);

            imgView = FindViewById<ImageView>(Resource.Id.imageView);
            btnAnimacao = FindViewById<Button>(Resource.Id.btnAnimacao);

            btnAnimacao.Click += BtnAnimacao_Click;
          }

        private void BtnAnimacao_Click(object sender, System.EventArgs e)
        {
            ObjectAnimator animatorX = ObjectAnimator.OfFloat(imgView, "scaleX", 0.5f, 1f);
            animatorX.SetDuration(5000);
            //animatorX.Start();

            ObjectAnimator animatorY = ObjectAnimator.OfFloat(imgView, "scaleY", 0.5f, 1f);
            animatorY.SetDuration(5000);
            //animatorY.Start();

            AnimatorSet animaSet = new AnimatorSet();
            animaSet.PlayTogether(animatorX, animatorY);
            animaSet.Start();
        }
    }
}

