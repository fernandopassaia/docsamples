﻿using Android.App;
using Android.Widget;
using Android.OS;
using Android.Views;

namespace Droid_RadioButtons
{
    [Activity(Label = "Droid_RadioButtons", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        Button btnEnviar;
        RadioGroup rdgrp1;

        [Java.Interop.Export("radioButton_OnClick")]
        public void radioButton_OnClick(View v)
        {
            switch(v.Id)
            {
                case Resource.Id.rdbCShp:
                    Toast.MakeText(this, "Muito bem, C# é mesmo uma ótima linguagem...", ToastLength.Short).Show();
                    break;
                case Resource.Id.rdbJava:
                    Toast.MakeText(this, "Muito bem, Java é mesmo uma ótima linguagem...", ToastLength.Short).Show();
                    break;
                case Resource.Id.rdbVBNet:
                    Toast.MakeText(this, "Muito bem, VB .NET é mesmo uma ótima linguagem...", ToastLength.Short).Show();
                    break;
            }
        }


        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView (Resource.Layout.Main);
            btnEnviar = FindViewById<Button>(Resource.Id.btnEnviar);
            rdgrp1 = FindViewById<RadioGroup>(Resource.Id.radioGroup1);

            btnEnviar.Click += BtnEnviar_Click;
        }

        private void BtnEnviar_Click(object sender, System.EventArgs e)
        {
            RadioButton checkedRadioButton = FindViewById<RadioButton>(rdgrp1.CheckedRadioButtonId);

            if (checkedRadioButton.Text == "C#")
            {
                Toast.MakeText(this, "Muito bem, C# é mesmo uma ótima linguagem...", ToastLength.Short).Show();
            }
            else
            {
                Toast.MakeText(this, "Esta linguagem também é muito boa.", ToastLength.Short).Show();
            }
        }
    }
}

