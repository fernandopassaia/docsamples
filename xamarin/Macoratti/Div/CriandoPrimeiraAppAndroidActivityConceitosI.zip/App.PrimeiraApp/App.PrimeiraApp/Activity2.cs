
using Android.App;
using Android.OS;
using Android.Widget;

namespace App.PrimeiraApp
{
    [Activity(Label = "Segunda Atividade")]
    public class Activity2 : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            // Create your application here
            SetContentView(Resource.Layout.layout1);

            Button button = FindViewById<Button>(Resource.Id.macButton);

            button.Click += delegate
            {
                StartActivity(typeof(MainActivity));
            };
        }
    }
}