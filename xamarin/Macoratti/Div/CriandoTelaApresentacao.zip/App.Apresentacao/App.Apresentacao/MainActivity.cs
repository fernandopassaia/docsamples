﻿using Android.App;
using Android.OS;
using Android.Widget;

namespace App.Apresentacao
{
    [Activity(Label = "App.Apresentacao", Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView(Resource.Layout.Main);
            Button button = FindViewById<Button>(Resource.Id.MyButton);

            button.Click += delegate
            {
                Toast.MakeText(this, "Macoratti .net", ToastLength.Short).Show();
            };
        }
    }
}

