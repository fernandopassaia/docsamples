using Android.App;
using Android.Content;
using Android.OS;
using Android.Widget;

namespace App.Login_SQLite
{
    [Activity(Label = "LoginActivity")]
    public class LoginActivity : Activity
    {
        TextView txtTextoLogin;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.Login);
            txtTextoLogin = FindViewById<TextView>(Resource.Id.txtTextoLogin);
           //pega os dados obtidos na primeira atividade e exibe no TextField
            FindViewById<TextView>(Resource.Id.txtTextoLogin).Text = txtTextoLogin.Text + " : " + Intent.GetStringExtra("nome") ?? "Erro ao obter os dados";
        }
    }
}