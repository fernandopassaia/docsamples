using Android.App;
using Android.OS;
using Android.Widget;
using SQLite;
using System;
using System.IO;

namespace App.Login_SQLite
{
    [Activity(Label = "RegistrarActivity")]
    public class RegistrarActivity : Activity
    {
        EditText txtNovoUsuario;
        EditText txtSenhaNovoUsuario;
        Button btnCriarNovoUsuario;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.NovoUsuario);

            btnCriarNovoUsuario = FindViewById<Button>(Resource.Id.btnRegistrar);
            txtNovoUsuario = FindViewById<EditText>(Resource.Id.txtNovoUsuario);
            txtSenhaNovoUsuario = FindViewById<EditText>(Resource.Id.txtSenhaNovoUsuario);

            btnCriarNovoUsuario.Click += BtnCriarNovoUsuario_Click;
        }

        private void BtnCriarNovoUsuario_Click(object sender, System.EventArgs e)
        {
            try
            {
                string dpPath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "Usuario.db3");
                var db = new SQLiteConnection(dpPath);
                db.CreateTable<Login>();
                Login tblogin = new Login();
                tblogin.usuario = txtNovoUsuario.Text;
                tblogin.senha = txtSenhaNovoUsuario.Text;
                db.Insert(tblogin);
                Toast.MakeText(this, "Registro inclu�do com sucesso...,", ToastLength.Short).Show();
            }
            catch (Exception ex)
            {
                Toast.MakeText(this, ex.ToString(), ToastLength.Short).Show();
            }
        }
    }
}