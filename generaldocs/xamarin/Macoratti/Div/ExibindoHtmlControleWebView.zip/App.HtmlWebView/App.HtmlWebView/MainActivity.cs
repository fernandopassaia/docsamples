﻿using Android.App;
using Android.OS;
using Android.Webkit;
using Android.Widget;

namespace App.HtmlWebView
{
    [Activity(Label = "App.HtmlWebView", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        EditText txtUrl;
        WebView webview1;
        Button btnCarregarSite;
        Button btnCarregarHtml;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.Main);

            //cria instãncia dos controles usados na view principal
            txtUrl = FindViewById<EditText>(Resource.Id.txtUrl);
            btnCarregarSite = FindViewById<Button>(Resource.Id.btnCarregarSite);
            btnCarregarHtml = FindViewById<Button>(Resource.Id.btnCarregarHtml);
            webview1 = FindViewById<WebView>(Resource.Id.webView1);
            webview1.Settings.JavaScriptEnabled = true;

            //define os eventos dos botões
            btnCarregarSite.Click += BtnCarregarSite_Click;
            btnCarregarHtml.Click += BtnCarregarHtml_Click;

        }

        private void BtnCarregarHtml_Click(object sender, System.EventArgs e)
        {
            //define um conteúdo html estático
            string html = "<html><body><h1>Ola, WebView</h1>" +
            "<hr/>" +
            "<h2>Macoratti.net</h2>" +
            "<h3>Quase Tudo para a plataforma .NET</h3>" +
            "<h4>http://www.macoratti.net</h4>" +
            "<p>Xamarin Android - WebView</p>" +
            "</body></html>";
            webview1.LoadData(html, "text/html", "UTF-8");
        }

        private void BtnCarregarSite_Click(object sender, System.EventArgs e)
        {
            //cria uma instância de WebViewClient
            webview1.SetWebViewClient(new MeuWebViewClient());

            //carrega a url a ser renderizada no WebView
            //txtUrl.Text obtém o texto digitado
            webview1.LoadUrl(txtUrl.Text);
        }

        public class MeuWebViewClient : WebViewClient
        {
            public override bool ShouldOverrideUrlLoading(WebView view, string url)
            {
                view.LoadUrl(url);
                return true;
            }
        }
    }
}

