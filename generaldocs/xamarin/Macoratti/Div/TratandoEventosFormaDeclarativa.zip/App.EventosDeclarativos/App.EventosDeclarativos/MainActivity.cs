﻿using Android.App;
using Android.OS;
using Android.Views;
using Android.Widget;
using Java.Interop;

namespace App.EventosDeclarativos
{
    [Activity(Label = "App.EventosDeclarativos", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        int count = 1;

        [Export("btn_Evento")]
        public void button_Click(View v)
        {
            Toast.MakeText(this, "Evento Click", ToastLength.Short).Show();
            (v as Button).Text = string.Format("{0} cliques !", count++);
        }

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);
       
        }
    }
}

