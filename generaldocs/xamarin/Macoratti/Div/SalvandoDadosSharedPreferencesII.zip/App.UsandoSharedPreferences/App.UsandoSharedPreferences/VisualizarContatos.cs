using Android.App;
using Android.OS;
using Android.Widget;

namespace App.UsandoSharedPreferences
{
    [Activity(Label = "Contatos")]
    public class VisualizarContatos : ListActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            var localContatos = Application.Context.GetSharedPreferences("contatos", Android.Content.FileCreationMode.Private);
            string nome = localContatos.GetString("Nome", null);
            string email = localContatos.GetString("Email", null);

            Contato _contato = new Contato(nome, email);

            Contato[] listaContatos = { _contato };
            ListAdapter = new ArrayAdapter<Contato>(this, Android.Resource.Layout.SimpleListItem1, listaContatos);
        }
    }
}