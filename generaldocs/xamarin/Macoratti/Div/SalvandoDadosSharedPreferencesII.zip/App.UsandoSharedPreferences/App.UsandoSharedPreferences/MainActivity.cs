﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Widget;

namespace App.UsandoSharedPreferences
{
    [Activity(Label = "Cadastro", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            Button btnEnviar = FindViewById<Button>(Resource.Id.btnEnviar);

            btnEnviar.Click += delegate
            {
                EditText txtNome = FindViewById<EditText>(Resource.Id.txtNome);
                string nome = txtNome.Text;
                EditText txtEmail = FindViewById<EditText>(Resource.Id.txtEmail);
                string email = txtEmail.Text;

                var localContatos = Application.Context.GetSharedPreferences("contatos", Android.Content.FileCreationMode.Private);
                var contatoEdit = localContatos.Edit();
                contatoEdit.PutString("Nome", nome);
                contatoEdit.PutString("Email", email);
                contatoEdit.Commit();

                Toast.MakeText(this, "Dados inseridos", ToastLength.Short).Show();
                txtNome.Text = "";
                txtEmail.Text = "";
            };

            Button btnVisualizar = FindViewById<Button>(Resource.Id.btnVisualizar);

            btnVisualizar.Click += delegate
            {
                var intent = new Intent(this, typeof(VisualizarContatos));
                StartActivity(intent);
            };
        }
    }
}

