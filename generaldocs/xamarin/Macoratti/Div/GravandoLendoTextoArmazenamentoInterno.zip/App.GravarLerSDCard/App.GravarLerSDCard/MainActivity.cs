﻿using Android.App;
using Android.OS;
using Android.Widget;

namespace App.GravarLerSDCard
{
    [Activity(Label = "App.GravarLerSDCard", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        TextView txtv1;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView(Resource.Layout.Main);
            Button button = FindViewById<Button>(Resource.Id.btnLer);
            txtv1 = FindViewById<TextView>(Resource.Id.txtAcao);

            button.Click += Button_Click;

            EscreverArquivo();

        }

        private void EscreverArquivo()
        {
            var sdCardPath = Android.OS.Environment.ExternalStorageDirectory.Path;
            var arquivoPath = System.IO.Path.Combine(sdCardPath, "ArqSDCard2.txt");
            if (!System.IO.File.Exists(arquivoPath))
            {
                using (System.IO.StreamWriter writer = new System.IO.StreamWriter(arquivoPath, true))
                {
                    writer.Write("Macoratti .net - Quase tudo para .NET");
                    Toast.MakeText(this, "Arquivo " + arquivoPath.ToString() + " gerado com sucesso.", ToastLength.Short).Show();
                }
            }
            else
            {
                Toast.MakeText(this, "Arquivo " + arquivoPath.ToString() + " já existe.", ToastLength.Short).Show();
            }
        }

        private void Button_Click(object sender, System.EventArgs e)
        {
            var sdCardPath = Android.OS.Environment.ExternalStorageDirectory.Path;
            var arquivoPath = System.IO.Path.Combine(sdCardPath, "ArqSDCard1.txt");

            if (System.IO.File.Exists(arquivoPath))
            {
                var texto = System.IO.File.ReadAllText(arquivoPath);
                txtv1.Text = texto;
                Toast.MakeText(this, "Arquivo lido com sucesso.", ToastLength.Short).Show();
            }
            else
            {
                Toast.MakeText(this, "Arquivo " + arquivoPath.ToString() + " não encontrado.", ToastLength.Short).Show();
            }
        }
    }
}

