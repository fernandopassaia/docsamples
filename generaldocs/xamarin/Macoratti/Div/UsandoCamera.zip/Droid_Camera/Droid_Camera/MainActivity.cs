﻿using Android.App;
using Android.Widget;
using Android.OS;
using Android.Content;
using Android.Provider;
using Android.Runtime;
using Android.Graphics;
using System;

namespace Droid_Camera
{
    [Activity(Label = "Droid_Camera", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        ImageView imgView1;
        Button btnCamera;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView (Resource.Layout.Main);
            btnCamera = FindViewById<Button>(Resource.Id.btnCamera);
            imgView1 = FindViewById<ImageView>(Resource.Id.imgvw1);

            btnCamera.Click += BtnCamera_Click;

        }

        protected override void OnActivityResult(int requestCode, [GeneratedEnum] Result resultCode, Intent data)
        {
            base.OnActivityResult(requestCode, resultCode, data);
            global::Android.Graphics.Bitmap bitmap = (Bitmap)data.Extras.Get("data");
            imgView1.SetImageBitmap(bitmap);
        }

        private void BtnCamera_Click(object sender, System.EventArgs e)
        {
            Intent intent = new Intent(MediaStore.ActionImageCapture);
            StartActivityForResult(intent, 0);
        }
    }
}

