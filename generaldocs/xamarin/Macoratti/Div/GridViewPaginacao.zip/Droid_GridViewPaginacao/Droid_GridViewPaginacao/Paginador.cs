﻿using System.Collections;

namespace Droid_GridViewPaginacao
{
    public class Paginador
    {
        //CONSTANTES
        public const int TOTAL_NUM_ITEMS = 54;
        public const int ITEMS_POR_PAGINA = 10;
        public const int ITEMS_RESTANTES = TOTAL_NUM_ITEMS % ITEMS_POR_PAGINA;
        public const int ULTIMA_PAGINA = TOTAL_NUM_ITEMS / ITEMS_POR_PAGINA;
        /*
         * GERA UMA ÚNICA PÁGINA DE DADOS
         */
        public ArrayList GerarPagina(int paginaAtual)
        {
            int itemInicial = paginaAtual * ITEMS_POR_PAGINA + 1;
            const int numDados = ITEMS_POR_PAGINA;

            ArrayList paginaDeDados = new ArrayList();

            if (paginaAtual == ULTIMA_PAGINA && ITEMS_RESTANTES > 0)
            {
                for (int i = itemInicial; i < itemInicial + ITEMS_RESTANTES; i++)
                {
                    paginaDeDados.Add("Numero " + i);
                }
            }
            else
            {
                for (int i = itemInicial; i < itemInicial + numDados; i++)
                {
                    paginaDeDados.Add("Numero " + i);
                }
            }
            return paginaDeDados;
        }
    }
}