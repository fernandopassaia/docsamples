﻿using Android.App;
using Android.Widget;
using Android.OS;

namespace Droid_GridViewPaginacao
{
    [Activity(Label = "Droid_GridViewPaginacao", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        private GridView gv;
        private Button proxBtn, anteBtn;
        private readonly Paginador pag = new Paginador();
        private const int totalPaginas = Paginador.TOTAL_NUM_ITEMS / Paginador.ITEMS_POR_PAGINA;
        private int paginaAtual = 0;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView (Resource.Layout.Main);
            this.initializeViews();
            //Vincula a primeira pagina
            gv.Adapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1, pag.GerarPagina(paginaAtual));
        }

        private void initializeViews()
        {
            //Referencia as views
            gv = FindViewById<GridView>(Resource.Id.gdvDados);
            proxBtn = FindViewById<Button>(Resource.Id.btnProximo);
            anteBtn = FindViewById<Button>(Resource.Id.btnAnterior);

            anteBtn.Enabled = false;
            //Eventos Clicks dos botões
            proxBtn.Click += ProxBtn_Click;
            anteBtn.Click += AnteBtn_Click;
        }

        //ANterior
        private void AnteBtn_Click(object sender, System.EventArgs e)
        {
            paginaAtual -= 1;
            gv.Adapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1, pag.GerarPagina(paginaAtual));
            AlternarBotoes();
        }

        //Proximo
        private void ProxBtn_Click(object sender, System.EventArgs e)
        {
            paginaAtual += 1;
            gv.Adapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1, pag.GerarPagina(paginaAtual));
            AlternarBotoes();
        }

        /*
        * Alterna o estado dos botões
        */
        private void AlternarBotoes()
        {
            if (paginaAtual == totalPaginas)
            {
                proxBtn.Enabled = false;
                anteBtn.Enabled = true;
            }
            else
            if (paginaAtual == 0)
            {
                anteBtn.Enabled = false;
                proxBtn.Enabled = true;
            }
            else
            if (paginaAtual >= 1 && paginaAtual <= 5)
            {
                proxBtn.Enabled = true;
                anteBtn.Enabled = true;
            }
        }
    }
}

