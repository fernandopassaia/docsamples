﻿using Android.App;
using Android.OS;
using Android.Widget;
using System.Collections.Generic;

namespace App.TutorialListView
{
    [Activity(Label = "App.TutorialListView", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        private List<string> times;
        private ListView listView;
        //string[] items;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            //poderiamos ter criado um array de strings
            //items = new string[] { "Santos", "Vasco", "Palmeiras", "Cruzeiro", "Sport", "Grêmio" };

            SetContentView(Resource.Layout.Main);
            listView = FindViewById<ListView>(Resource.Id.lvDados);

            times = new List<string>();
            times.Add("Santos");
            times.Add("Grêmio");
            times.Add("Coritiba");
            times.Add("Flamengo");
            times.Add("São Paulo");
            times.Add("Palmeiras");
            times.Add("Vasco");
            times.Add("Bahia");
            times.Add("Corinthians");
            times.Add("Sport");
            times.Add("Internacional");
            times.Add("Cruzeiro");
            times.Add("Atletico");
            times.Add("Vitoria");

            ArrayAdapter<string> adapter = new ArrayAdapter<string>(this, Android.Resource.Layout.SimpleListItem1, times);
            listView.Adapter = adapter;

            listView.ItemClick += (sender, e) =>
            {
                using (var dialog = new AlertDialog.Builder(this))
                {
                    int posicao = e.Position;
                    string valor = times[posicao];
                    dialog.SetIcon(Android.Resource.Drawable.IcDialogAlert);
                    dialog.SetTitle("Time Selecionado");
                    dialog.SetMessage(valor);
                    dialog.Show();
                }
            };
        }
    }
}

