﻿using SQLite;

namespace Droid_SQLiteDB.Model
{
    class Contato
    {
        [PrimaryKey]
        public string ID { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
    }
}