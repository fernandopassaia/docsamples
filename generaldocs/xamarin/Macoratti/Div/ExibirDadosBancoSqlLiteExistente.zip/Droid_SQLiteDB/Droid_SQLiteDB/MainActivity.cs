﻿using Android.App;
using Android.Widget;
using Android.OS;
using Android.Database.Sqlite;
using Droid_SQLiteDB.Model;
using Droid_SQLiteDB.Service;
using System.Collections.Generic;
using Android.Database;
using Android.Views;
using Android.Content;

namespace Droid_SQLiteDB
{
    [Activity(Label = "Droid_SQLiteDB", MainLauncher = true)]
    public class MainActivity : Activity
    {
        DBHelper db;
        SQLiteDatabase sqliteDB;
        LinearLayout container;
        Button btnGetDados;
        List<Contato> listaContatos = new List<Contato>();

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);
            db = new DBHelper(this);
            sqliteDB = db.WritableDatabase;
            container = FindViewById<LinearLayout>(Resource.Id.container);
            btnGetDados = FindViewById<Button>(Resource.Id.btnCarregaDados);
            btnGetDados.Click += delegate
            {
                ObtemDados();
            };
        }
        private void ObtemDados()
        {
            ICursor dadosSelecionados = sqliteDB.RawQuery("select * from Contato", new string[] { });
            if (dadosSelecionados.Count > 0)
            {
                dadosSelecionados.MoveToFirst();
                do
                {
                    Contato contato = new Contato();
                    contato.ID = dadosSelecionados.GetString(dadosSelecionados.GetColumnIndex("ID"));
                    contato.Nome = dadosSelecionados.GetString(dadosSelecionados.GetColumnIndex("Nome"));
                    contato.Email = dadosSelecionados.GetString(dadosSelecionados.GetColumnIndex("Email"));
                    listaContatos.Add(contato);
                }
                while (dadosSelecionados.MoveToNext());
                dadosSelecionados.Close();
            }
            foreach (var item in listaContatos)
            {
                LayoutInflater layoutInflater = (LayoutInflater)BaseContext.GetSystemService(Context.LayoutInflaterService);
                View addView = layoutInflater.Inflate(Resource.Layout.row, null);
                TextView txtID = addView.FindViewById<TextView>(Resource.Id.txtID);
                TextView txtNome = addView.FindViewById<TextView>(Resource.Id.txtNome);
                TextView txtEmail = addView.FindViewById<TextView>(Resource.Id.txtEmail);
                txtID.Text = item.ID;
                txtNome.Text = item.Nome;
                txtEmail.Text = item.Email;
                container.AddView(addView);
            }
        }
    }
}

