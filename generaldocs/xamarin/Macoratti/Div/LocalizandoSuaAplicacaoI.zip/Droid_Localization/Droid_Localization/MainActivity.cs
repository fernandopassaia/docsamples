﻿using Android.App;
using Android.Widget;
using Android.OS;
using System.Threading;
using System.Globalization;
using System.Resources;
using System.Reflection;
using Android.Locations;

namespace Droid_Localization
{
    [Activity(Label = "@string/app", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        // Loading the resurce files containing culture info and set culture to "es-ES"
        //string sLangCode = "es-ES";
        //ResourceManager resxManager = new ResourceManager("Droid_Localization.AppResources.Lang", Assembly.GetExecutingAssembly());
        ////Loaded the culture info

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView (Resource.Layout.Main);

            //obtem o locale atual
            //var lang = Resources.Configuration.Locale;

            // Setting the language accordin to Language 
            // Set culture by changing sLangCode
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo(sLangCode);
            //Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(sLangCode);
            // End set culture info

            var btnCancel = FindViewById<Button>(Resource.Id.btnCancel);
            var btnAdd = FindViewById<Button>(Resource.Id.btnAdd);
            var btnNotes = FindViewById<Button>(Resource.Id.btnNotes);
            var btnDone = FindViewById<Button>(Resource.Id.btnDone);

            //var cancelText = Resources.GetText(Resource.String.cancel);
            //var addText = Resources.GetText(Resource.String.add);
            //var notesText = Resources.GetText(Resource.String.notes);
            //var doneText = Resources.GetText(Resource.String.done);

            if (btnCancel != null)
            {
                btnCancel.Text = GetString(Resource.String.cancel); //cancelText;
            }
            if (btnAdd != null)
            {
                btnAdd.Text = Resources.GetText(Resource.String.add);  //resxManager.GetString("add");//Resources.GetText(Resource.String.add);
            }
            if (btnNotes != null)
            {
                btnNotes.Text = Resources.GetText(Resource.String.notes);  //resxManager.GetString("notes");//Resources.GetText(Resource.String.notes);
            }
            if (btnDone != null)
            {
                btnDone.Text = Resources.GetText(Resource.String.done); //resxManager.GetString("done");//Resources.GetText(Resource.String.done);
            }
        }
    }
}

