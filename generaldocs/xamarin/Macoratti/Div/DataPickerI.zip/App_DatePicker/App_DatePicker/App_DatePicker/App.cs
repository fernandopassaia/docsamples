﻿using Xamarin.Forms;

namespace App_DatePicker
{
    public class App : Application
    {
        public App()
        {

            Label lbltitulo = new Label
            {
                Text = "Calendário",
                FontSize = 40,
                HorizontalOptions = LayoutOptions.Center
            };


            DatePicker dtp = new DatePicker
            {
                Format = "d",
                VerticalOptions = LayoutOptions.CenterAndExpand
            };

            Label lblData = new Label
            {
                Text = "",
                FontSize = 40,
                TextColor = Color.Yellow,
                HorizontalOptions = LayoutOptions.Center
            };


            dtp.DateSelected += (s, e) =>
            {
                lblData.Text = "Data : " + e.NewDate.Day + "/" + e.NewDate.Month + "/" + e.NewDate.Year;
            };

            //StackLayout pilha = new StackLayout
            //{
            //    Children =
            //    {
            //        lbltitulo,dtp,lblData
            //    }
            //};

            MainPage = new ContentPage
            {
                BackgroundColor = Color.Black,
                Content = new StackLayout
                {
                    Orientation = StackOrientation.Vertical,

                    Children =
                    {
                        lbltitulo,dtp,lblData
                    }
                }
            };
        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
