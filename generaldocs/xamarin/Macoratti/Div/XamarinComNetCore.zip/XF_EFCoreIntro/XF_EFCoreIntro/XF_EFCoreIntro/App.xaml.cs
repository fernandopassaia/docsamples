using System.Collections.Generic;
using System.Linq;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using XF_EFCoreIntro.Models;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
namespace XF_EFCoreIntro
{
    public partial class App : Application
	{
        public App(string dbPath)
        {
            InitializeComponent();

            List<Cliente> listaClientes;

            // Cria o banco de dados e as tabelas
            using (var db = new AppDbContext(dbPath))
            {
                // Ensure database is created
                db.Database.EnsureCreated();

                // Inserindo dados : usando o m�todo Add e SaveChanges
                db.Add(new Cliente() { Nome = "Maria da Silva" });
                db.Add(new Cliente() { Nome = "Jos� Rocha Siqueira" });
                db.Add(new Cliente() { Nome = "Pedro dos Santos"});
                db.SaveChanges();

                // Retornando os dados
                listaClientes = db.Clientes.ToList();
            }

            MainPage = new MainPage()
            {
                Content = new ListView()
                {
                    ItemsSource = listaClientes
                }
            };
		}

		protected override void OnStart ()
		{
			// Handle when your app starts
		}

		protected override void OnSleep ()
		{
			// Handle when your app sleeps
		}

		protected override void OnResume ()
		{
			// Handle when your app resumes
		}
	}
}
