﻿using Android.App;
using Android.OS;

namespace Droid_Tabs2
{
    [Activity(Label = "Droid_Tabs2", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView (Resource.Layout.Main);

            // habilita o modo de navegação para suporar a tab layout
            this.ActionBar.NavigationMode = ActionBarNavigationMode.Tabs;

            //adiciona a tab Audio
            AddTab("Audio", Resource.Drawable.Icon, new AudioFragment());

            //adiciona a tab Video
            AddTab("Video", Resource.Drawable.Icon, new VideoFragment());
        }

        void AddTab(string tabText, int iconResourceId, Fragment fragment)
        {
            var tab = this.ActionBar.NewTab();
            tab.SetText(tabText);
            tab.SetIcon(iconResourceId);

            // define o tratamento de eventos para substituir as tabs
            tab.TabSelected += delegate (object sender, ActionBar.TabEventArgs e) {
                e.FragmentTransaction.Replace(Resource.Id.fragmentContainer, fragment);
            };

            this.ActionBar.AddTab(tab);
        }
    }
}

