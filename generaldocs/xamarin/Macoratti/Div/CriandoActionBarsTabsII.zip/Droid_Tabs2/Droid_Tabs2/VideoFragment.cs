using Android.App;
using Android.OS;
using Android.Views;
using Android.Widget;

namespace Droid_Tabs2
{
    public class VideoFragment : Fragment
    {
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            base.OnCreateView(inflater, container, savedInstanceState);

            var view = inflater.Inflate(Resource.Layout.layoutTab, container, false);
            var sampleTextView = view.FindViewById<TextView>(Resource.Id.textView);
            sampleTextView.Text = "Video Fragment";
            return view;
        }
    }
}