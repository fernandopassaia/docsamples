﻿using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;
using XF_CustomControls;
using XF_CustomControls.iOS;

[assembly: ExportRenderer(typeof(MacEntry), typeof(MacEntryRender))]
namespace XF_CustomControls.iOS
{
    public class MacEntryRender : EntryRenderer
    {
        protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
        {
            base.OnElementChanged(e);
            if (Control != null)
            {
                Control.BackgroundColor = UIColor.LightGray;
                Control.BorderStyle = UITextBorderStyle.Line;
            }
        }
    }
}