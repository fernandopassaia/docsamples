﻿using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;
using XF_CustomControls;
using XF_CustomControls.Droid;

[assembly: ExportRenderer(typeof(MacEntry), typeof(MacEntryRender))]
namespace XF_CustomControls.Droid
{
    public class MacEntryRender : EntryRenderer
    {
        protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
        {
            base.OnElementChanged(e);
            if (Control != null)
                Control.SetBackgroundColor(global::Android.Graphics.Color.LightBlue);
        }
    }
}