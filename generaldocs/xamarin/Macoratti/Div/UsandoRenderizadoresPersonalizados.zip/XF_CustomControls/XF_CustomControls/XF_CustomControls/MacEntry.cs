﻿using Xamarin.Forms;
namespace XF_CustomControls
{
    public class MacEntry : Entry
    {}
}
