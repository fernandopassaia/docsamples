﻿using System;
using Xamarin.Forms;

namespace XF_Navegacao2
{
    public partial class Pagina1 : ContentPage
    {
        public Pagina1()
        {
            InitializeComponent();
        }

        private async void btnEnviar_Clicked(object sender, EventArgs e)
        {
            var contato = new Contato
            {
                Nome = txtNome.Text,
                Idade = Convert.ToInt32(txtIdade.Text),
                Cargo = txtCargo.Text,
                Pais = txtPais.Text
            };

            var pagina2 = new Pagina2();
            pagina2.BindingContext = contato;
            await Navigation.PushAsync(pagina2);
        }
    }
}
