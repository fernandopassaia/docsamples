﻿using Android.App;
using Android.OS;
using Android.Util;
using Android.Widget;
using System;

namespace App.SpinnerSimples2
{
    [Activity(Label = "App.SpinnerSimples2", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.Main);
            Spinner spinner = FindViewById<Spinner>(Resource.Id.spinDados);
            try
            {
                var adapter = ArrayAdapter.CreateFromResource(
                        this, Resource.Array.estados_array, Android.Resource.Layout.SimpleSpinnerItem);

                adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
                spinner.Adapter = adapter;

                spinner.ItemSelected += new EventHandler<AdapterView.ItemSelectedEventArgs>(spinner_ItemSelected);
            }
            catch (Exception ex)
            {
                Log.Debug(GetType().FullName, ex.Message);
            }
        }

        private void spinner_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {
            Spinner spinner = (Spinner)sender;

            string toast = string.Format("Estado selecionado : {0}", spinner.GetItemAtPosition(e.Position));
            Toast.MakeText(this, toast, ToastLength.Long).Show();
        }
    }
}

