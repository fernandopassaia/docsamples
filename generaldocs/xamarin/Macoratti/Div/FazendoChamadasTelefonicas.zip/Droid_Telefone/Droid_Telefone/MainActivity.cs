﻿using Android.App;
using Android.Content;
using Android.Widget;
using Android.OS;
using Uri = Android.Net.Uri;
using Android;
using System;

[assembly: UsesPermission(Manifest.Permission.CallPhone)]
[assembly: UsesFeature(Android.Content.PM.PackageManager.FeatureTelephony)]

namespace Droid_Telefone
{
    [Activity(Label = "Droid_Telefone", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        EditText editText;
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView (Resource.Layout.Main);
            editText = FindViewById<EditText>(Resource.Id.editText);
            Button btnChamada = FindViewById<Button>(Resource.Id.fazerChamada);

            if (!PackageManager.HasSystemFeature(Android.Content.PM.PackageManager.FeatureTelephony))
            {
                Toast.MakeText(this,"O dispositivo não suporta este recurso.",ToastLength.Short);
                return;
            }

            btnChamada.Click += BtnChamada_Click;
        }

        private void BtnChamada_Click(object sender, EventArgs e)
        {
            var intent = new Intent(Intent.ActionCall);
            intent.SetData(Uri.Parse("tel:" + editText.Text));
            StartActivity(intent);
        }
    }
}

