﻿using Android.App;
using Android.Widget;
using Android.OS;
using Android.Content;

namespace Droid_Email
{
    [Activity(Label = "Droid_Email", MainLauncher = true)]
    public class MainActivity : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);
            var edtxtPara = FindViewById<EditText>(Resource.Id.edtxtPara);
            var edtxtAssunto = FindViewById<EditText>(Resource.Id.edtxtAssunto);
            var edtxtMensagem = FindViewById<EditText>(Resource.Id.edtxtMensagem);
            var btnEnviar = FindViewById<Button>(Resource.Id.btnEnviar);

            btnEnviar.Click += (s, e) =>
            {
                Intent email = new Intent(Intent.ActionSend);
                email.PutExtra(Intent.ExtraEmail, new string[] { edtxtPara.Text.ToString() });
                email.PutExtra(Intent.ExtraSubject, edtxtAssunto.Text.ToString());
                email.PutExtra(Intent.ExtraText, edtxtMensagem.Text.ToString());
                email.SetType("message/rfc822");
                StartActivity(Intent.CreateChooser(email, "Enviar email Via"));

            };
        }
    }
}

