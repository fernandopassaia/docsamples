﻿using Android.App;
using Android.Widget;
using Android.OS;
using RestSharp;

namespace Droid_RestApi
{
    [Activity(Label = "RestAPI", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        ProgressDialog dialog;
        TextView txtv1;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView (Resource.Layout.Main);
            Button button = FindViewById<Button>(Resource.Id.btnAcessar);
            txtv1 = FindViewById<TextView>(Resource.Id.txtResposta);

            button.Click += Button_Click;
        }

        private void Button_Click(object sender, System.EventArgs e)
        {
            dialog = new ProgressDialog(this);
            dialog.SetMessage("Aguarde...");
            dialog.SetProgressStyle(ProgressDialogStyle.Spinner);
            dialog.Show();

            var cliente = new RestClient("http://www.androidcodec.com");
            var request = new RestRequest("/", Method.GET);
            request.AddHeader("Content-type", "application/json");
            cliente.ExecuteAsync(request, response =>
            {
                RunOnUiThread(delegate
                {
                    dialog.Dismiss();
                    var responseFacebook = response.Content;
                    txtv1.Text = responseFacebook.ToString();        
                    Toast.MakeText(this, "reposta", ToastLength.Long);
                });
            });
        }
    }
}

