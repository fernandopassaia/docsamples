﻿
using Xamarin.Forms;

namespace App_DataPicker2
{
    public partial class Calendario : ContentPage
    {
        public Calendario()
        {
            InitializeComponent();
        }

        //private void OnDateSelected(object sender, DateChangedEventArgs e)
        //{
        //    lblData.Text = e.NewDate.Day + "/" + e.NewDate.Month + "/" + e.NewDate.Year;
        //}
    }
}
