﻿using Android.App;
using Android.OS;
using Android.Widget;

namespace App.CalculadoraFlex
{
    [Activity(Label = "App.CalculadoraFlex", MainLauncher = true, Icon = "@drawable/calc")]
    public class MainActivity : Activity
    {
        EditText vlrAlcool;
        EditText vlrGasolina;
        TextView txtAlcool;
        TextView txtGasolina;
        Button btnCalcular;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView(Resource.Layout.Main);

            txtAlcool = FindViewById<TextView>(Resource.Id.txtValorAlcool);
            txtAlcool.SetTextColor(Android.Graphics.Color.White);

            txtGasolina = FindViewById<TextView>(Resource.Id.txtValorGasolina);
            txtGasolina.SetTextColor(Android.Graphics.Color.White);

            vlrAlcool = FindViewById<EditText>(Resource.Id.valor_alcool);
            vlrAlcool.SetBackgroundColor(Android.Graphics.Color.Blue);
            vlrAlcool.SetCursorVisible(true);

            vlrGasolina = FindViewById<EditText>(Resource.Id.valor_gasolina);
            vlrGasolina.SetBackgroundColor(Android.Graphics.Color.White);
            vlrGasolina.SetCursorVisible(true);

            btnCalcular = FindViewById<Button>(Resource.Id.btnCalcular);
            btnCalcular.SetBackgroundColor(Android.Graphics.Color.Green);
            btnCalcular.SetTextColor(Android.Graphics.Color.Black);

            btnCalcular.Click += BtnCalcular_Click;
        }

        private void BtnCalcular_Click(object sender, System.EventArgs e)
        {

            double valor_Alcool = double.Parse(vlrAlcool.Text);
            double valor_Gasolina = double.Parse(vlrGasolina.Text);

            double resultado = (valor_Alcool / valor_Gasolina);

            if (resultado > 0.70)
            {
                ExibeMensagem("Abasteça com Gasolina !");
            }
            else
            {
                ExibeMensagem("Abasteça com Álcool !");
            }

        }

        private void ExibeMensagem(string texto)
        {
            //define o alerta para executar a tarefa
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            AlertDialog alerta = builder.Create();
            //Define o Titulo
            alerta.SetTitle("Calculadora Flex");
            //define o icone
            alerta.SetIcon(Android.Resource.Drawable.IcDialogAlert);
            //define o texto
            alerta.SetMessage(texto);
            //define o button
            alerta.SetButton("OK", (s, ev) =>
            {
                //define uma mensagem que se desvaneçe
                Toast.MakeText(this, texto, ToastLength.Long).Show();

            });
            alerta.Show();
        }
    }
}

