﻿using Android.App;
using Android.Media;
using Android.OS;
using Android.Widget;

namespace App.Som
{
    [Activity(Label = "App.Som", MainLauncher = true, Icon = "@drawable/play")]
    public class MainActivity : Activity
    {
        MediaPlayer _myPlayer;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.Main);

            _myPlayer = MediaPlayer.Create(this, Resource.Raw.CarolOfBells);

            Button button = FindViewById<Button>(Resource.Id.MyButton);
            button.SetBackgroundColor(Android.Graphics.Color.Red);

            Button tocar = FindViewById<Button>(Resource.Id.btnTocar);
            Button parar = FindViewById<Button>(Resource.Id.btnParar);
            Button pausar = FindViewById<Button>(Resource.Id.btnPausar);
            Button reiniciar = FindViewById<Button>(Resource.Id.btnReiniciar);
            Button online = FindViewById<Button>(Resource.Id.btnOnLine);

            button.Click += delegate
            {

                _myPlayer.Start();
            };
            tocar.Click += Tocar_Click;
            parar.Click += Parar_Click;
            pausar.Click += Pausar_Click;
            reiniciar.Click += Reiniciar_Click;
            online.Click += Online_Click;
        }

        private void Online_Click(object sender, System.EventArgs e)
        {
            string url = "http://macoratti.net/audio/CarolOfBells.mp3";
            _myPlayer = new MediaPlayer();
            _myPlayer.SetAudioStreamType(Stream.Music);
            _myPlayer.SetDataSource(url);
            _myPlayer.Prepare();
            _myPlayer.Start();
        }

        private void Reiniciar_Click(object sender, System.EventArgs e)
        {
            _myPlayer.Start();
        }

        private void Pausar_Click(object sender, System.EventArgs e)
        {
            _myPlayer.Pause();
        }

        private void Parar_Click(object sender, System.EventArgs e)
        {
            _myPlayer.Stop();
        }

        private void Tocar_Click(object sender, System.EventArgs e)
        {
            _myPlayer.Start();
        }
    }
}

