using Android.App;
using Android.OS;
using Android.Widget;

namespace App.PrimeiraApp
{
    [Activity(Label = "Segunda Atividade")]
    public class Activity2 : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            // Create your application here
            SetContentView(Resource.Layout.layout1);

            Button button = FindViewById<Button>(Resource.Id.macButton);
            string texto = Intent.GetStringExtra("MeusDados") ?? "Dados n�o dispon�veis";
            button.Text = texto;

            //pega os dados obtidos na primeira atividade e exibe no TextField
            FindViewById<TextView>(Resource.Id.editText2).Text = Intent.GetStringExtra("nome") ?? "Erro ao obter os dados";

            button.Click += delegate
            {
                StartActivity(typeof(MainActivity));
            };
        }
    }
}