﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Widget;

namespace App.PrimeiraApp
{
    [Activity(Label = "App.PrimeiraApp", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        int count = 1;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            // Get our button from the layout resource,
            // and attach an event to it
            Button button = FindViewById<Button>(Resource.Id.MyButton);

            button.Click += delegate
            {
                button.Text = string.Format("{0} clique!", count++);
                var activity2 = new Intent(this, typeof(Activity2));
                activity2.PutExtra("MeusDados", "Dados da Atividade Activity2");

                //pega os dados digitados em editText1
                activity2.PutExtra("nome", FindViewById<EditText>(Resource.Id.editText1).Text);

                StartActivity(activity2);
            };
        }
    }
}

