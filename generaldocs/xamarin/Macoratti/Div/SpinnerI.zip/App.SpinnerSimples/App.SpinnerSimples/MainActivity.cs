﻿using Android.App;
using Android.OS;
using Android.Widget;
using System.Collections;

namespace App.SpinnerSimples
{
    [Activity(Label = "App.SpinnerSimples", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        Spinner spinner;
        ArrayAdapter adapter;
        ArrayList estados;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView(Resource.Layout.Main);

            GetEstados();

            spinner = FindViewById<Spinner>(Resource.Id.spnDados);
            adapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1, estados);

            spinner.Adapter = adapter;

            spinner.ItemSelected += Spinner_ItemSelected;
        }

        private void Spinner_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {
            Spinner spinner = (Spinner)sender;

            string toast = string.Format("Estado selecionado: {0}", spinner.GetItemAtPosition(e.Position));
            Toast.MakeText(this, toast, ToastLength.Long).Show();
        }

        private void GetEstados()
        {
            estados = new ArrayList();
            estados.Add("São Paulo");
            estados.Add("Rio de Janeiro");
            estados.Add("Minas Gerais");
            estados.Add("Paraná");
            estados.Add("Santa Catarina");
            estados.Add("Rio Grande do Sul");
            estados.Add("Espirito Santo");
        }
    }
}

