﻿using Android.App;
using Android.OS;
using Android.Widget;
using System.Collections;

namespace App.GridViewAdapter
{
    [Activity(Label = "App.GridViewAdapter", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        GridView gv;
        ArrayAdapter adpt;
        ArrayList lista;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            gv = FindViewById<GridView>(Resource.Id.gdvDados);
            Dados();
            adpt = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1, lista);
            gv.Adapter = adpt;

            gv.ItemClick += Gv_ItemClick;

        }

        private void Gv_ItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            Toast.MakeText(this, lista[e.Position].ToString(), ToastLength.Short).Show();
        }

        private void Dados()
        {
            lista = new ArrayList();
            lista.Add("Maria");
            lista.Add("Pedro");
            lista.Add("João");
            lista.Add("Sandra");
            lista.Add("Carlos");
            lista.Add("Eduardo");
            lista.Add("Andre");
            lista.Add("Marcia");
            lista.Add("Debora");
            lista.Add("Cristina");
            lista.Add("Luiz");
            lista.Add("Antonio");
            lista.Add("Paulo");
            lista.Add("Beatriz");
        }
    }
}

