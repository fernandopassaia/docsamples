﻿using Android.App;
using Android.Widget;
using Android.OS;
using Android.Content;

namespace Droid_MasterDetail
{
    [Activity(Label = "Droid_MasterDetail", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView (Resource.Layout.Main);
            var button = FindViewById<Button>(Resource.Id.btnNavegar);
            button.Click += Button_Click;
        }

        private void Button_Click(object sender, System.EventArgs e)
        {
            var intent = new Intent(this, typeof(CalendarActivity));
            StartActivity(intent);
        }
    }
}

