
using Android.App;
using Android.OS;
using Android.Widget;

namespace Droid_MasterDetail
{
    [Activity(Label = "DetalhesActivity", ParentActivity =typeof(MainActivity))]
    public class DetalhesActivity : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.DetalhesLayout);
            var textView = FindViewById<TextView>(Resource.Id.txtvwUrl);
            textView.Text = Intent.GetStringExtra("url") ?? "Sem dados";
        }
    }
}