﻿using Android.App;
using Android.OS;
using Android.Widget;

namespace App.CustomAdapterListView
{
    [Activity(Label = "App.CustomAdapterListView", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {

        protected override void OnCreate(Bundle bundle)
        {
            //Main line of code
            //AppDomain.CurrentDomain.UnhandledException += CurrentDomainOnUnhandledException;
            //TaskScheduler.UnobservedTaskException += TaskSchedulerOnUnobservedTaskException;

            base.OnCreate(bundle);
            SetContentView(Resource.Layout.Main);

            var filmesListView = FindViewById<ListView>(Resource.Id.filmeslistView);

            filmesListView.FastScrollEnabled = true;

            filmesListView.ItemClick += FilmesListView_ItemClick;

            var filmesAdapter = new FilmeAdapter(this, FilmesRepositorio.Filmes);

            filmesListView.Adapter = filmesAdapter;
        }

        private void FilmesListView_ItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            Toast.MakeText(this, FilmesRepositorio.Filmes[e.Position].ToString(), ToastLength.Long).Show();
        }

        //private static void TaskSchedulerOnUnobservedTaskException(object sender, UnobservedTaskExceptionEventArgs unobservedTaskExceptionEventArgs)
        //{
        //    var newExc = new Exception("TaskSchedulerOnUnobservedTaskException", unobservedTaskExceptionEventArgs.Exception);
        //    LogUnhandledException(newExc);
        //}

        //private static void CurrentDomainOnUnhandledException(object sender, UnhandledExceptionEventArgs unhandledExceptionEventArgs)
        //{
        //    var newExc = new Exception("CurrentDomainOnUnhandledException", unhandledExceptionEventArgs.ExceptionObject as Exception);
        //    LogUnhandledException(newExc);
        //}

        //internal static void LogUnhandledException(Exception exception)
        //{
        //    try
        //    {
        //        const string errorFileName = "Fatal.txt";
        //        var errorFilePath = GetLocalPath(errorFileName);
        //        var errorMessage = String.Format("Time: {0}\r\nError: Unhandled Exception\r\n{1}", DateTime.Now, exception.ToString());
        //        File.WriteAllText(errorFilePath, errorMessage);
        //    }
        //    catch (Exception)
        //    {
        //        // just suppress any error logging exceptions
        //    }
        //}

        //public static string GetLocalPath(string fileName)
        //{
        //    string dir = Path.Combine(Android.OS.Environment.ExternalStorageDirectory.ToString(), "Exception");
        //    if (Directory.Exists(dir))
        //        return Path.Combine(dir, fileName);
        //    return Path.Combine(Directory.CreateDirectory(dir).FullName, fileName);
        //}
    }
}

