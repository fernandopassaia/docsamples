﻿using Android.App;
using Android.OS;
using Android.Widget;

namespace App.DemoAutoCompleteTextView
{
    [Activity(Label = "App.AutoCompleteTextView", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        AutoCompleteTextView autoCompletar1;
        Button btnEnviar;
        string[] estados;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // define a view a partir do recurso de layout Main
            SetContentView(Resource.Layout.Main);

            estados = new string[] { "Amazonas", "Alagoas", "Amapá", "Santa Catarina", "Sergipe", "São Paulo", "Roraima", "Rio de Janeiro", "Rio Grande do Sul", "Minas Gerais", "Mato Grosso" };

            autoCompletar1 = FindViewById<AutoCompleteTextView>(Resource.Id.autoCompletetxt1);
            autoCompletar1.Threshold = 1;
            btnEnviar = FindViewById<Button>(Resource.Id.btnEnviar);

            ArrayAdapter adapter = new ArrayAdapter<string>(this, Android.Resource.Layout.SimpleListItem1, estados);

            autoCompletar1.Adapter = adapter;


            btnEnviar.Click += delegate
            {
                if (autoCompletar1.Text != "")
                {
                    Toast.MakeText(this, " Estado = " + autoCompletar1.Text, ToastLength.Short).Show();
                }
                else
                {
                    Toast.MakeText(this, " Informe o nome do Estado ", ToastLength.Short).Show();
                }
            };
        }
    }
}

