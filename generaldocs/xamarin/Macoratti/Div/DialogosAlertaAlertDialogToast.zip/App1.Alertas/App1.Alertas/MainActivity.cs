﻿using Android.App;
using Android.OS;
using Android.Widget;

namespace App1.Alertas
{
    [Activity(Label = "App1.Alertas", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        int count = 1;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView(Resource.Layout.Main);

            Button button = FindViewById<Button>(Resource.Id.MyButton);
            button.Click += delegate
            {
                button.Text = string.Format("{0} cliques !", count++);

                //define o alerta para executar a tarefa
                AlertDialog.Builder builder = new AlertDialog.Builder(this);

                AlertDialog alerta = builder.Create();

                //Define o Titulo
                alerta.SetTitle("Macoratti .net - Deseja Continuar");
                alerta.SetIcon(Android.Resource.Drawable.IcDialogAlert);
                alerta.SetMessage("Macoratti .net Quase tudo para a Plataforma .Net");

                alerta.SetButton("OK", (s, ev) =>
                {
                    Toast.MakeText(this, "Legal, vamos continuar... !", ToastLength.Short).Show();
                });
                alerta.Show();
            };

            Button btnAlerta = FindViewById<Button>(Resource.Id.btnAlerta);
            btnAlerta.Click += delegate
            {
                //define o alerta para executar a tarefa
                AlertDialog.Builder alerta = new AlertDialog.Builder(this);
                alerta.SetCancelable(true);
                alerta.SetIcon(Android.Resource.Drawable.IcInputAdd);
                //define o titulo
                alerta.SetTitle("Deseja Salvar o trabalho ?");

                //define a mensagem
                alerta.SetMessage("Macoratti .net - Quase tudo para a plataforma .NET");
                //define o botão positivo
                alerta.SetPositiveButton("Salvar", (senderAlert, args) =>
                {
                    Toast.MakeText(this, "Salvo com sucesso!", ToastLength.Short).Show();
                });
                //define o botão negativo
                alerta.SetNegativeButton("Cancelar", (senderAlert, args) =>
                {
                    Toast.MakeText(this, "Cancelado !", ToastLength.Short).Show();
                });
                //cria o alerta e exibe
                Dialog dialogo = alerta.Create();
                dialogo.Show();
            };

            Button btnAlerta3 = FindViewById<Button>(Resource.Id.btnAlerta3);
            btnAlerta3.Click += delegate
            {
                //define o alerta para executar a tarefa
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                AlertDialog alerta = builder.Create();
                alerta.SetCancelable(true);
                alerta.SetIcon(Android.Resource.Drawable.IcDialogInfo);
                //define o titulo
                alerta.SetTitle("Diálogo com 3 Botões.");

                //define a mensagem
                alerta.SetMessage("Macoratti .net - Quase tudo para a plataforma .NET");

                alerta.SetButton("SIM", (s, ev) =>
                {
                    Toast.MakeText(this, "SIM !", ToastLength.Short).Show();
                });
                alerta.SetButton2("NÃO", (s, ev) =>
                {
                    Toast.MakeText(this, "NÃO !", ToastLength.Short).Show();
                });
                alerta.SetButton3("CANCELAR", (s, ev) =>
                {
                    Toast.MakeText(this, "CANCELAR !", ToastLength.Short).Show();
                });

                alerta.Show();
            };
        }
    }
}

