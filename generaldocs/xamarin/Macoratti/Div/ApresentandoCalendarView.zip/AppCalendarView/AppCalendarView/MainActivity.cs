﻿using Android.App;
using Android.OS;
using Android.Widget;

namespace AppCalendarView
{
    [Activity(Label = "AppCalendarView", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);
            var calend = FindViewById<CalendarView>(Resource.Id.calendview1);
            var txtData = FindViewById<TextView>(Resource.Id.txtExibir);

            txtData.Text = "Data : ";

            calend.DateChange += (s, e) =>
            {
                txtData.Text = "Data : " + e.DayOfMonth + "/" + (e.Month+1) + "/" + e.Year;
            };
        }
    }
}

