﻿using Mvc_UnityDI.Repository;
using System.Web.Mvc;

namespace Mvc_UnityDI.Controllers
{
    public class UsuariosController : Controller
    {
        readonly IUsuarioRepository usuarioRepositorio;
        public UsuariosController(IUsuarioRepository repository)
        {
            this.usuarioRepositorio = repository;
        }

        // GET: Usuarios
        public ActionResult Index()
        {
            var data = usuarioRepositorio.GetAll();
            return View(data);
        }
    }
}