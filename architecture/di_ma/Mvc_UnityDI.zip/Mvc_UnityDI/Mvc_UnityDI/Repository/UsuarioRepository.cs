﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Mvc_UnityDI.Repository
{
    public class UsuarioRepository : IUsuarioRepository
    {
        private List<Usuario> usuarios = new List<Usuario>();
        private int Id = 1;

        public UsuarioRepository()
        {
            // incluindo alguns usuários para demo
            Add(new Usuario { ID = 1, Nome = "Macoratti", Email = "macoratti@teste.com", Senha = "numsey@13" });
            Add(new Usuario { ID = 2, Nome = "Jefferson", Email = "jeff@teste.com", Senha = "ytedg6543" });
            Add(new Usuario { ID = 3, Nome = "Miriam", Email = "miriam3@teste.com", Senha = "#5496dskj" });
        }

        public Usuario Add(Usuario item)
        {
            if (item == null)
            {
                throw new ArgumentNullException(nameof(item));
            }

            item.ID = Id++;
            usuarios.Add(item);
            return item;
        }

        public bool Delete(int id)
        {
            usuarios.RemoveAll(p => p.ID == id);
            return true;
        }

        public Usuario Get(int id)
        {
            return usuarios.FirstOrDefault(x => x.ID == id);
        }

        public IEnumerable<Usuario> GetAll()
        {
            return usuarios;
        }

        public bool Update(Usuario item)
        {
            if (item == null)
            {
                throw new ArgumentNullException(nameof(item));
            }


            int index = usuarios.FindIndex(p => p.ID == item.ID);
            if (index == -1)
            {
                return false;
            }
            usuarios.RemoveAt(index);
            usuarios.Add(item);
            return true;
        }
    }
}