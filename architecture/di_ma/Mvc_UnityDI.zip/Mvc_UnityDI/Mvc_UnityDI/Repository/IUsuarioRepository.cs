﻿using System.Collections.Generic;

namespace Mvc_UnityDI.Repository
{
    public interface IUsuarioRepository
    {
        IEnumerable<Usuario> GetAll();
        Usuario Get(int id);
        Usuario Add(Usuario item);
        bool Update(Usuario item);
        bool Delete(int id);
    }
}
