﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net_ProgAsync.CLDemo
{
    public class Exemplo
    {
        //método Task com retorno Task<TResult>
        async Task<bool> Task_TResult_Async()
        {
            return await
            Task.FromResult<bool>(DateTime.IsLeapYear(DateTime.Now.Year));
        }

        //método com retorno void (Task)
        async Task Task_Void_Async()
        {
            await Task.Delay(5000);
            Console.WriteLine("5 segundos de atraso");
        }

        public async Task Task_LongaDuracao()
        {
            bool isAnoBissexto = await Task_TResult_Async();
            for (int i = 0; i <= 10000; i++)
            {
                i++;
            }
            isAnoBissexto = await Task_TResult_Async();

            Console.WriteLine($"{DateTime.Now.Year} {(isAnoBissexto ? " é " : " não é ")} um Ano Bissexto");
            await Task_Void_Async();

            Task taskTResultAsync = Task_TResult_Async();
            for (int i = 0; i <= 10000; i++)
            {
                i++;
            }
            await taskTResultAsync;
        }
    }
}
