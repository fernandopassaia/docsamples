﻿using Net_ProgAsync.CLDemo;
using System;
using System.Windows.Forms;

namespace Net_ProgAsync.WF
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void btnExecutar_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Evento do botão foi iniciado : cliquei aqui");

            Exemplo oProgAsync = new Exemplo();
            await oProgAsync.Task_LongaDuracao();

            Console.WriteLine("Evento do botão foi concluído");
        }
    }
}
