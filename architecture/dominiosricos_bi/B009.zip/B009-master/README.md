# B009 - Criando Domínios Ricos: Domínio

### LINK PARA OS VÍDEOS
Você pode assistir os vídeos deste curso sendo um assinante do site http://balta.io.

### Sumário
Escrever código é uma arte, e como toda arte, tem seus princípios, seus padrões, seus guias.

### Conteúdo Programático
* O que é o DDD?
* Quando devo aplicar DDD?
* Elementos do DDD
* Entidades VS Value Objects
* Agregates e Agregate Roots
* Repositórios
* Serviços
* Domain Events
