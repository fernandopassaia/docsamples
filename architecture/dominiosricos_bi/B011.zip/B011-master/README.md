# B011 - Criando Domínios Ricos: Testes

### LINK PARA OS VÍDEOS
Você pode assistir os vídeos deste curso sendo um assinante do site http://balta.io.

### Sumário
Escrever código é uma arte, e como toda arte, tem seus princípios, seus padrões, seus guias.

### Conteúdo Programático
* DDD ou TDD?
* O que eu devo testar?
* Arrange, Act, Assert
* Testando por acerto
* Testando por excessões
* Testando o domínio
* Fake Repository
* Mocks
