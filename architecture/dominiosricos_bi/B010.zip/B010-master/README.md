# B010 - Criando Domínios Ricos: SOLID 

### LINK PARA OS VÍDEOS
Você pode assistir os vídeos deste curso sendo um assinante do site http://balta.io.

### Sumário
Escrever código é uma arte, e como toda arte, tem seus princípios, seus padrões, seus guias.

### Conteúdo Programático
* Single Responsibility Principle
* Open/Closed Principle
* Liskov Substitution Principle
* Interface Segregation Principle
* Dependency Inversion Principle
* Dont Repeat Yourself Principle
