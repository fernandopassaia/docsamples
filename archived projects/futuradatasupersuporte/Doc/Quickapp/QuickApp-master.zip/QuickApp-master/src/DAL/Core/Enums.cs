﻿// ====================================================
// More Templates: https://www.ebenmonney.com/templates
// Email: support@ebenmonney.com
// ====================================================

using System;

namespace DAL.Core
{
    public enum Gender
    {
        None,
        Female,
        Male
    }
}
