export const environment = {
  production: true,
  serviceUrl: 'http://mwaonlineteste/'
};
