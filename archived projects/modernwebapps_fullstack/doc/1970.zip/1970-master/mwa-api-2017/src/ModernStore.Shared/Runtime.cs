﻿namespace ModernStore.Shared
{
    public static class Runtime
    {
        public static string ConnectionString = "";
    }
}
