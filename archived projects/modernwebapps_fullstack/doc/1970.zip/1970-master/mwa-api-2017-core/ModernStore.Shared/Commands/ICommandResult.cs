﻿namespace ModernStore.Shared.Commands
{
    public interface ICommandResult
    {
    }
}
