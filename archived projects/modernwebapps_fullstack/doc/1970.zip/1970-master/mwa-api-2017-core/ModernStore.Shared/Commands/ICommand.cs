﻿namespace ModernStore.Shared.Commands
{
    public interface ICommand
    {
    }
}
