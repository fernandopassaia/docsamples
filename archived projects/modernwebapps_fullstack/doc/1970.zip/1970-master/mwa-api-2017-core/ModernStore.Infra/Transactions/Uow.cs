﻿namespace ModernStore.Infra.Transactions
{
    public class Uow : IUow
    {
        public void Commit()
        {
            //
        }

        public void Rollback()
        {
            // Do nothing :)
        }
    }
}
