// =============================
// Email: info@ebenmonney.com
// www.ebenmonney.com/templates
// =============================

export enum Gender {
    None,
    Female,
    Male
}
