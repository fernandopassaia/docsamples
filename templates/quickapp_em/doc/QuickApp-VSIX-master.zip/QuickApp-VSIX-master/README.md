# QuickApp-VSIX
Visual Studio Extension (VSIX) for the ASP.NET Core 2.1 / Angular7 QuickApp project
* Extension hosted on Visual Studio Marketplace: https://marketplace.visualstudio.com/items?itemName=adentum.QuickApp-ASPNETCoreAngularXProjectTemplate
* Actual Project on Github: https://github.com/emonney/QuickApp
* Live demo on http://quickapp.ebenmonney.com


## License

Released under the [MIT License](https://github.com/emonney/QuickApp/blob/master/LICENSE).


I would love to hear your [feedback](mailto:contact@ebenmonney.com) | [www.ebenmonney.com](https://www.ebenmonney.com/contact)