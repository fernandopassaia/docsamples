<!--
Hi there and thank you for your feature request! 🆕🆕🆕

If you want to report a bug, use this link instead:
  https://github.com/react-native-community/react-native-device-info/issues/new

-->

## Description

<!-- What would you like to see implemented? How? -->

## Use Case

<!-- Describe a scenario where this feature could come handy -->
