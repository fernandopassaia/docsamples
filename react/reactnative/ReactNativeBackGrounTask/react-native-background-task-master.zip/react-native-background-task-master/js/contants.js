// @flow

export default {
  UNAVAILABLE_DENIED: 'denied',
  UNAVAILABLE_RESTRICTED: 'restricted',
}