Example project using [react-native-background-task](https://github.com/jamesisaac/react-native-background-task) to run periodic background tasks in a simple React Native app.

## Installation

Clone the repo and run `npm install`